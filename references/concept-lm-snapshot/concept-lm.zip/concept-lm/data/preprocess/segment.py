"""
data/preprocess/segment.py

Sentence segmentation for legal opinion text.

Takes cleaned .txt files from data/raw_clean/ and produces per-document
sentence lists stored as JSON files in data/segmented/.

Two segmenters supported (configured via configs/train_default.yaml):
    spacy:  SpaCy en_core_web_sm rule-based segmenter. Fast and reliable
            for well-formed legal prose. Struggles with very long sentences
            and citation-dense passages.

    sat:    Segment any Text (SaT) — a neural segmenter that is more robust
            to non-standard punctuation and citation interruptions.
            Requires: pip install wtpsplit

Legal-specific post-processing applied regardless of segmenter:
    - Sentences shorter than MIN_SENTENCE_CHARS are merged with the next sentence.
    - Sentences longer than MAX_SENTENCE_CHARS are split on semicolons/colons first,
      then on coordinating conjunctions if still too long.
    - Citation-only sentences (e.g. "See, e.g., Smith v. Jones, 411 U.S. 792.") are
      merged with the preceding sentence to avoid encoding isolated citations as concepts.
    - Footnote markers (digits or letters in brackets) are stripped.

Output format per document (data/segmented/{case_id}.json):
    {
        "case_id": "12345678",
        "source": "data/raw_clean/12345678.txt",
        "n_sentences": 142,
        "sentences": ["The court finds ...", "Plaintiff argues ...", ...]
    }

Usage:
    python -m data.preprocess.segment \
        --input-dir data/raw_clean/ \
        --output-dir data/segmented/ \
        --segmenter spacy \
        --workers 4
"""

from __future__ import annotations

import re
import json
import logging
import argparse
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor, as_completed
from typing import Optional

from tqdm import tqdm

logger = logging.getLogger(__name__)

MIN_SENTENCE_CHARS = 30
MAX_SENTENCE_CHARS = 600
CITATION_PATTERN = re.compile(
    r"^(See(,\s*e\.g\.,)?|Id\.|Ibid\.|cf\.|accord)\s+.{0,200}\.$",
    re.IGNORECASE,
)
FOOTNOTE_MARKER = re.compile(r"\[\d+\]|\(\d+\)|(?<!\w)\d{1,3}(?!\w)")


def strip_metadata_header(text: str) -> str:
    lines = text.splitlines()
    for i, line in enumerate(lines):
        if not line.startswith("#") and line.strip():
            return "\n".join(lines[i:])
    return text


def segment_spacy(text: str) -> list[str]:
    try:
        import spacy
        nlp = spacy.load("en_core_web_sm", disable=["ner", "tagger", "lemmatizer"])
    except OSError:
        raise RuntimeError(
            "SpaCy model not found. Run: python -m spacy download en_core_web_sm"
        )
    doc = nlp(text)
    return [sent.text.strip() for sent in doc.sents if sent.text.strip()]


def segment_sat(text: str) -> list[str]:
    try:
        from wtpsplit import SaT
        sat = SaT("sat-3l")
    except ImportError:
        raise RuntimeError("wtpsplit not installed. Run: pip install wtpsplit")
    sentences = sat.split(text)
    return [s.strip() for s in sentences if s.strip()]


def postprocess(sentences: list[str]) -> list[str]:
    """
    Legal-specific cleaning and merging/splitting.
    """
    result: list[str] = []

    for sent in sentences:
        # Strip footnote markers
        sent = FOOTNOTE_MARKER.sub("", sent).strip()
        if not sent:
            continue

        # Merge very short sentences into previous
        if len(sent) < MIN_SENTENCE_CHARS and result:
            result[-1] = result[-1].rstrip() + " " + sent
            continue

        # Merge citation-only sentences into previous
        if CITATION_PATTERN.match(sent) and result:
            result[-1] = result[-1].rstrip() + " " + sent
            continue

        # Split overly long sentences
        if len(sent) > MAX_SENTENCE_CHARS:
            parts = _split_long_sentence(sent)
            result.extend(parts)
        else:
            result.append(sent)

    # Final pass: remove empty and deduplicate adjacent identical
    cleaned: list[str] = []
    for s in result:
        s = s.strip()
        if s and (not cleaned or s != cleaned[-1]):
            cleaned.append(s)

    return cleaned


def _split_long_sentence(sent: str) -> list[str]:
    """
    Attempt to split a sentence that exceeds MAX_SENTENCE_CHARS.
    Priority: semicolons → colons → " and " / " but " / " or "
    """
    for delimiter in ["; ", ": ", " and ", " but ", " or "]:
        parts = sent.split(delimiter)
        if len(parts) > 1:
            result = []
            for i, part in enumerate(parts):
                if i < len(parts) - 1:
                    part = part + delimiter.rstrip()
                part = part.strip()
                if len(part) >= MIN_SENTENCE_CHARS:
                    result.append(part)
                elif result:
                    result[-1] += " " + part
            if result:
                return result

    # Cannot split — return as-is (will be a long concept)
    return [sent]


def process_file(
    path: Path,
    output_dir: Path,
    segmenter: str = "spacy",
) -> Optional[dict]:
    """Process one .txt file. Returns summary dict or None on error."""
    case_id = path.stem
    out_path = output_dir / f"{case_id}.json"
    if out_path.exists():
        return {"case_id": case_id, "status": "skipped"}

    try:
        text = path.read_text(encoding="utf-8", errors="replace")
        body = strip_metadata_header(text)

        if segmenter == "sat":
            raw_sentences = segment_sat(body)
        else:
            raw_sentences = segment_spacy(body)

        sentences = postprocess(raw_sentences)

        record = {
            "case_id": case_id,
            "source": str(path),
            "n_sentences": len(sentences),
            "sentences": sentences,
        }
        out_path.write_text(json.dumps(record, ensure_ascii=False, indent=2))
        return {"case_id": case_id, "n_sentences": len(sentences), "status": "ok"}

    except Exception as e:
        logger.warning(f"Error processing {path.name}: {e}")
        return {"case_id": case_id, "status": "error", "error": str(e)}


def segment_corpus(
    input_dir: str,
    output_dir: str,
    segmenter: str = "spacy",
    workers: int = 4,
) -> dict:
    in_path = Path(input_dir)
    out_path = Path(output_dir)
    out_path.mkdir(parents=True, exist_ok=True)

    files = sorted(in_path.glob("*.txt"))
    logger.info(f"Segmenting {len(files)} files with '{segmenter}'")

    results = {"ok": 0, "skipped": 0, "error": 0, "total_sentences": 0}

    if workers == 1:
        for f in tqdm(files, desc="Segmenting"):
            r = process_file(f, out_path, segmenter)
            if r:
                results[r["status"]] = results.get(r["status"], 0) + 1
                results["total_sentences"] += r.get("n_sentences", 0)
    else:
        with ProcessPoolExecutor(max_workers=workers) as pool:
            futures = {
                pool.submit(process_file, f, out_path, segmenter): f
                for f in files
            }
            for fut in tqdm(as_completed(futures), total=len(futures), desc="Segmenting"):
                r = fut.result()
                if r:
                    results[r["status"]] = results.get(r["status"], 0) + 1
                    results["total_sentences"] += r.get("n_sentences", 0)

    logger.info(f"Segmentation complete: {results}")
    (out_path / "segment_report.json").write_text(json.dumps(results, indent=2))
    return results


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
    parser = argparse.ArgumentParser(description="Sentence-segment legal opinion corpus")
    parser.add_argument("--input-dir", default="data/raw_clean/")
    parser.add_argument("--output-dir", default="data/segmented/")
    parser.add_argument("--segmenter", choices=["spacy", "sat"], default="spacy")
    parser.add_argument("--workers", type=int, default=4)
    args = parser.parse_args()

    results = segment_corpus(args.input_dir, args.output_dir, args.segmenter, args.workers)
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
