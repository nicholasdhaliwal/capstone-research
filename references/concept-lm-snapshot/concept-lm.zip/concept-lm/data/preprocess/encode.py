"""
data/preprocess/encode.py

SONAR sentence encoding — offline preprocessing step.

Reads segmented JSON files from data/segmented/ and encodes each sentence
into a 1024-dimensional SONAR embedding. Embeddings are stored as float32
.npy arrays in data/encoded/.

SONAR is only used here — at training time the embeddings are loaded from
disk, and at inference time SONAR is not needed at all.

Output per document (data/encoded/{case_id}_sonar.npy):
    shape: (N_sentences, 1024)  float32

The encoder processes documents in batches for efficiency.
On a single A100, encoding 50,000 sentences takes approximately 20 minutes.
On CPU it will be slower — set --batch-size 8 to avoid OOM.

Usage:
    python -m data.preprocess.encode \
        --input-dir data/segmented/ \
        --output-dir data/encoded/ \
        --batch-size 32 \
        --device cuda
"""

from __future__ import annotations

import json
import logging
import argparse
from pathlib import Path
from typing import Optional

import numpy as np
import torch
from tqdm import tqdm

logger = logging.getLogger(__name__)

SONAR_DIM = 1024
SOURCE_LANG = "eng_Latn"


def load_sonar_encoder(device: str = "cuda"):
    """
    Load the SONAR text encoder pipeline.
    Requires: pip install sonar-space fairseq2
    """
    try:
        from sonar.inference_pipelines.text import TextToEmbeddingModelPipeline
    except ImportError:
        raise RuntimeError(
            "SONAR not installed. Run:\n"
            "    pip install sonar-space fairseq2\n"
            "SONAR is required for preprocessing only — not for training or inference."
        )
    encoder = TextToEmbeddingModelPipeline(
        encoder="text_sonar_basic_encoder",
        tokenizer="text_sonar_basic_encoder",
        device=torch.device(device),
    )
    return encoder


def encode_sentences(
    sentences: list[str],
    encoder,
    batch_size: int = 32,
) -> np.ndarray:
    """
    Encode a list of sentences into SONAR embeddings.

    Returns:
        embeddings: (N, 1024) float32 numpy array
    """
    all_embeddings = []

    for i in range(0, len(sentences), batch_size):
        batch = sentences[i:i + batch_size]
        # Filter empty strings — SONAR will error on them
        batch = [s if s.strip() else "." for s in batch]
        with torch.no_grad():
            emb = encoder.predict(batch, source_lang=SOURCE_LANG)  # (B, 1024)
        all_embeddings.append(emb.cpu().float().numpy())

    return np.concatenate(all_embeddings, axis=0)  # (N, 1024)


def process_file(
    json_path: Path,
    output_dir: Path,
    encoder,
    batch_size: int = 32,
) -> Optional[dict]:
    case_id = json_path.stem
    out_path = output_dir / f"{case_id}_sonar.npy"

    if out_path.exists():
        return {"case_id": case_id, "status": "skipped"}

    try:
        record = json.loads(json_path.read_text(encoding="utf-8"))
        sentences = record.get("sentences", [])
        if not sentences:
            return {"case_id": case_id, "status": "error", "error": "no sentences"}

        embeddings = encode_sentences(sentences, encoder, batch_size=batch_size)

        # L2-normalize (SONAR embeddings are already normalized but we enforce it)
        norms = np.linalg.norm(embeddings, axis=1, keepdims=True)
        embeddings = embeddings / np.maximum(norms, 1e-8)

        np.save(out_path, embeddings)
        return {"case_id": case_id, "n_sentences": len(sentences), "status": "ok"}

    except Exception as e:
        logger.warning(f"Error encoding {json_path.name}: {e}")
        return {"case_id": case_id, "status": "error", "error": str(e)}


def encode_corpus(
    input_dir: str,
    output_dir: str,
    batch_size: int = 32,
    device: str = "cuda",
) -> dict:
    in_path = Path(input_dir)
    out_path = Path(output_dir)
    out_path.mkdir(parents=True, exist_ok=True)

    json_files = sorted(in_path.glob("*.json"))
    # Skip report files
    json_files = [f for f in json_files if "report" not in f.name]
    logger.info(f"Encoding {len(json_files)} documents with SONAR on {device}")

    encoder = load_sonar_encoder(device)
    results = {"ok": 0, "skipped": 0, "error": 0, "total_sentences": 0}

    for path in tqdm(json_files, desc="Encoding"):
        r = process_file(path, out_path, encoder, batch_size=batch_size)
        if r:
            results[r["status"]] = results.get(r["status"], 0) + 1
            results["total_sentences"] += r.get("n_sentences", 0)

    logger.info(f"Encoding complete: {results}")
    (out_path / "encode_report.json").write_text(json.dumps(results, indent=2))
    return results


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
    parser = argparse.ArgumentParser(description="SONAR-encode segmented legal opinions")
    parser.add_argument("--input-dir", default="data/segmented/")
    parser.add_argument("--output-dir", default="data/encoded/")
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()

    results = encode_corpus(args.input_dir, args.output_dir, args.batch_size, args.device)
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
