"""
data/preprocess/build_dataset.py

Final dataset assembly step.

Joins tokenized arrays and SONAR embeddings for each case, validates
alignment, and writes split directories (train / val / test).

Each processed case contributes three files to data/processed/{split}/:
    {case_id}_tokens.npy      int32  (L,)       token IDs
    {case_id}_sonar.npy       float32 (M, 1024)  SONAR sentence embeddings
    {case_id}_boundaries.npy  uint8  (L,)       sentence boundary indicators

Alignment validation:
    The number of sentences in the SONAR array must match the number of
    boundary positions (sum of boundaries array). Cases that fail alignment
    are logged and excluded from the final dataset.

Split assignment is deterministic (seeded shuffle) so reruns produce the
same splits.

Usage:
    python -m data.preprocess.build_dataset \
        --tokenized-dir data/tokenized/ \
        --encoded-dir data/encoded/ \
        --output-dir data/processed/ \
        --train-frac 0.85 \
        --val-frac 0.10 \
        --seed 42
"""

from __future__ import annotations

import json
import shutil
import logging
import random
import argparse
from pathlib import Path

import numpy as np
from tqdm import tqdm

logger = logging.getLogger(__name__)


def find_cases(tokenized_dir: Path, encoded_dir: Path) -> list[str]:
    """
    Return case IDs that have all three required files.
    """
    token_files = {f.stem.replace("_tokens", "") for f in tokenized_dir.glob("*_tokens.npy")}
    sonar_files = {f.stem.replace("_sonar", "") for f in encoded_dir.glob("*_sonar.npy")}
    boundary_files = {
        f.stem.replace("_boundaries", "") for f in tokenized_dir.glob("*_boundaries.npy")
    }
    complete = token_files & sonar_files & boundary_files
    logger.info(
        f"Found {len(complete)} complete cases "
        f"(tokens: {len(token_files)}, sonar: {len(sonar_files)}, "
        f"boundaries: {len(boundary_files)})"
    )
    return sorted(complete)


def validate_case(case_id: str, tokenized_dir: Path, encoded_dir: Path) -> tuple[bool, str]:
    """
    Check that SONAR sentence count matches boundary count.
    Returns (valid, reason_if_invalid).
    """
    try:
        boundaries = np.load(tokenized_dir / f"{case_id}_boundaries.npy")
        sonar = np.load(encoded_dir / f"{case_id}_sonar.npy")

        n_boundaries = int(boundaries.sum())
        n_sonar = sonar.shape[0]

        if n_boundaries == 0:
            return False, "no boundaries"
        if n_sonar == 0:
            return False, "no sonar embeddings"
        if abs(n_boundaries - n_sonar) > max(3, int(0.05 * n_boundaries)):
            return False, (
                f"alignment mismatch: {n_boundaries} boundaries vs {n_sonar} sonar embeddings"
            )
        return True, ""

    except Exception as e:
        return False, str(e)


def copy_case(
    case_id: str,
    tokenized_dir: Path,
    encoded_dir: Path,
    dest_dir: Path,
) -> None:
    dest_dir.mkdir(parents=True, exist_ok=True)
    shutil.copy2(tokenized_dir / f"{case_id}_tokens.npy", dest_dir / f"{case_id}_tokens.npy")
    shutil.copy2(tokenized_dir / f"{case_id}_boundaries.npy", dest_dir / f"{case_id}_boundaries.npy")
    shutil.copy2(encoded_dir / f"{case_id}_sonar.npy", dest_dir / f"{case_id}_sonar.npy")


def build_dataset(
    tokenized_dir: str,
    encoded_dir: str,
    output_dir: str,
    train_frac: float = 0.85,
    val_frac: float = 0.10,
    seed: int = 42,
) -> dict:
    tok_path = Path(tokenized_dir)
    enc_path = Path(encoded_dir)
    out_path = Path(output_dir)

    cases = find_cases(tok_path, enc_path)
    if not cases:
        raise RuntimeError(
            "No complete cases found. Run segment.py, encode.py, and tokenize_corpus.py first."
        )

    # Validate alignment
    valid_cases = []
    invalid = []
    for case_id in tqdm(cases, desc="Validating"):
        ok, reason = validate_case(case_id, tok_path, enc_path)
        if ok:
            valid_cases.append(case_id)
        else:
            invalid.append({"case_id": case_id, "reason": reason})
            logger.debug(f"Invalid case {case_id}: {reason}")

    logger.info(f"Valid: {len(valid_cases)}, Invalid: {len(invalid)}")

    # Deterministic shuffle and split
    rng = random.Random(seed)
    rng.shuffle(valid_cases)

    n = len(valid_cases)
    n_train = int(n * train_frac)
    n_val = int(n * val_frac)

    splits = {
        "train": valid_cases[:n_train],
        "val": valid_cases[n_train:n_train + n_val],
        "test": valid_cases[n_train + n_val:],
    }

    # Copy files to split directories
    for split, case_ids in splits.items():
        split_dir = out_path / split
        for case_id in tqdm(case_ids, desc=f"Writing {split}"):
            copy_case(case_id, tok_path, enc_path, split_dir)

    report = {
        "total_valid": len(valid_cases),
        "total_invalid": len(invalid),
        "splits": {k: len(v) for k, v in splits.items()},
        "invalid_cases": invalid[:20],  # first 20 for inspection
    }
    (out_path / "dataset_report.json").write_text(json.dumps(report, indent=2))
    logger.info(f"Dataset built: {report['splits']}")
    return report


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
    parser = argparse.ArgumentParser(description="Assemble final train/val/test dataset")
    parser.add_argument("--tokenized-dir", default="data/tokenized/")
    parser.add_argument("--encoded-dir", default="data/encoded/")
    parser.add_argument("--output-dir", default="data/processed/")
    parser.add_argument("--train-frac", type=float, default=0.85)
    parser.add_argument("--val-frac", type=float, default=0.10)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    report = build_dataset(
        args.tokenized_dir, args.encoded_dir, args.output_dir,
        args.train_frac, args.val_frac, args.seed,
    )
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
