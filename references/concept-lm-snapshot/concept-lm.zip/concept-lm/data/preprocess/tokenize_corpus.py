"""
data/preprocess/tokenize_corpus.py

GPT-2 tokenization of the full opinion text and sentence boundary alignment.

Reads segmented JSON files and produces two aligned arrays per document:

    {case_id}_tokens.npy:     int32 (L,)
        Full token ID sequence for the entire opinion.

    {case_id}_boundaries.npy: uint8 (L,)
        Binary array: 1 at every token position that starts a new sentence,
        0 elsewhere. Used for Phase 1 boundary supervision.

Sentence boundary positions are determined by tokenizing each sentence
separately and recording the cumulative token offset.

Usage:
    python -m data.preprocess.tokenize_corpus \
        --input-dir data/segmented/ \
        --output-dir data/tokenized/ \
        --max-length 4096 \
        --workers 4
"""

from __future__ import annotations

import json
import logging
import argparse
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor, as_completed
from typing import Optional

import numpy as np
from tqdm import tqdm

logger = logging.getLogger(__name__)

_TOKENIZER = None


def get_tokenizer():
    global _TOKENIZER
    if _TOKENIZER is None:
        from transformers import GPT2Tokenizer
        _TOKENIZER = GPT2Tokenizer.from_pretrained("gpt2")
        _TOKENIZER.pad_token = _TOKENIZER.eos_token
    return _TOKENIZER


def process_file(
    json_path: Path,
    output_dir: Path,
    max_length: int = 4096,
) -> Optional[dict]:
    case_id = json_path.stem
    tokens_path = output_dir / f"{case_id}_tokens.npy"
    boundaries_path = output_dir / f"{case_id}_boundaries.npy"

    if tokens_path.exists() and boundaries_path.exists():
        return {"case_id": case_id, "status": "skipped"}

    try:
        record = json.loads(json_path.read_text(encoding="utf-8"))
        sentences = record.get("sentences", [])
        if not sentences:
            return {"case_id": case_id, "status": "error", "error": "no sentences"}

        tok = get_tokenizer()

        all_ids: list[int] = []
        all_boundaries: list[int] = []

        for sent in sentences:
            sent_ids = tok.encode(sent, add_special_tokens=False)
            if not sent_ids:
                continue
            start = len(all_ids)
            all_ids.extend(sent_ids)
            # Mark the first token of each sentence as a boundary
            boundary_row = [0] * len(sent_ids)
            boundary_row[0] = 1
            all_boundaries.extend(boundary_row)

        # Truncate to max_length
        all_ids = all_ids[:max_length]
        all_boundaries = all_boundaries[:max_length]

        if len(all_ids) < 10:
            return {"case_id": case_id, "status": "error", "error": "too short after tokenization"}

        np.save(tokens_path, np.array(all_ids, dtype=np.int32))
        np.save(boundaries_path, np.array(all_boundaries, dtype=np.uint8))

        return {
            "case_id": case_id,
            "n_tokens": len(all_ids),
            "n_sentences": len(sentences),
            "status": "ok",
        }

    except Exception as e:
        logger.warning(f"Error tokenizing {json_path.name}: {e}")
        return {"case_id": case_id, "status": "error", "error": str(e)}


def tokenize_corpus(
    input_dir: str,
    output_dir: str,
    max_length: int = 4096,
    workers: int = 4,
) -> dict:
    in_path = Path(input_dir)
    out_path = Path(output_dir)
    out_path.mkdir(parents=True, exist_ok=True)

    json_files = [f for f in sorted(in_path.glob("*.json")) if "report" not in f.name]
    logger.info(f"Tokenizing {len(json_files)} documents")

    results = {"ok": 0, "skipped": 0, "error": 0, "total_tokens": 0}

    if workers == 1:
        for f in tqdm(json_files, desc="Tokenizing"):
            r = process_file(f, out_path, max_length)
            if r:
                results[r["status"]] = results.get(r["status"], 0) + 1
                results["total_tokens"] += r.get("n_tokens", 0)
    else:
        with ProcessPoolExecutor(max_workers=workers) as pool:
            futures = {
                pool.submit(process_file, f, out_path, max_length): f
                for f in json_files
            }
            for fut in tqdm(as_completed(futures), total=len(futures), desc="Tokenizing"):
                r = fut.result()
                if r:
                    results[r["status"]] = results.get(r["status"], 0) + 1
                    results["total_tokens"] += r.get("n_tokens", 0)

    logger.info(f"Tokenization complete: {results}")
    (out_path / "tokenize_report.json").write_text(json.dumps(results, indent=2))
    return results


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
    parser = argparse.ArgumentParser(description="GPT-2 tokenize legal opinion corpus")
    parser.add_argument("--input-dir", default="data/segmented/")
    parser.add_argument("--output-dir", default="data/tokenized/")
    parser.add_argument("--max-length", type=int, default=4096)
    parser.add_argument("--workers", type=int, default=4)
    args = parser.parse_args()

    results = tokenize_corpus(args.input_dir, args.output_dir, args.max_length, args.workers)
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
