"""
data/inspect.py

Quick dataset statistics and sanity checks.

Reports per-split counts, token length distributions, SONAR embedding
statistics, and flags potential data issues.

Usage:
    python -m data.inspect --data-dir data/processed/
    python -m data.inspect --data-dir data/processed/ --split train --verbose
"""

from __future__ import annotations

import json
import argparse
import logging
from pathlib import Path

import numpy as np
from tqdm import tqdm

logger = logging.getLogger(__name__)


def inspect_split(split_dir: Path, verbose: bool = False) -> dict:
    token_files = sorted(split_dir.glob("*_tokens.npy"))
    if not token_files:
        return {"error": f"No token files in {split_dir}"}

    token_lengths, sonar_counts = [], []
    missing_sonar = []

    for tf in tqdm(token_files, desc=f"Inspecting {split_dir.name}", disable=not verbose):
        case_id = tf.stem.replace("_tokens", "")
        tokens = np.load(tf)
        token_lengths.append(len(tokens))

        sonar_path = split_dir / f"{case_id}_sonar.npy"
        if sonar_path.exists():
            sonar = np.load(sonar_path)
            sonar_counts.append(sonar.shape[0])
            # Check for NaN or zero vectors
            if verbose:
                if np.isnan(sonar).any():
                    logger.warning(f"{case_id}: NaN in SONAR embeddings")
                zero_rows = (np.abs(sonar).sum(axis=1) < 1e-6).sum()
                if zero_rows > 0:
                    logger.warning(f"{case_id}: {zero_rows} zero SONAR vectors")
        else:
            missing_sonar.append(case_id)

    tl = np.array(token_lengths)
    sc = np.array(sonar_counts) if sonar_counts else np.array([0])

    stats = {
        "n_cases": len(token_files),
        "missing_sonar": len(missing_sonar),
        "token_length": {
            "min": int(tl.min()),
            "max": int(tl.max()),
            "mean": float(tl.mean()),
            "median": float(np.median(tl)),
            "p95": float(np.percentile(tl, 95)),
        },
        "sentences_per_case": {
            "min": int(sc.min()),
            "max": int(sc.max()),
            "mean": float(sc.mean()),
            "median": float(np.median(sc)),
        },
        "total_tokens": int(tl.sum()),
        "total_sentences": int(sc.sum()),
    }
    return stats


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
    parser = argparse.ArgumentParser(description="Inspect processed dataset")
    parser.add_argument("--data-dir", default="data/processed/")
    parser.add_argument("--split", default=None, help="Inspect only this split")
    parser.add_argument("--verbose", action="store_true")
    args = parser.parse_args()

    data_path = Path(args.data_dir)
    splits = [args.split] if args.split else ["train", "val", "test"]

    report = {}
    for split in splits:
        split_dir = data_path / split
        if not split_dir.exists():
            report[split] = {"error": "directory not found"}
            continue
        report[split] = inspect_split(split_dir, verbose=args.verbose)

    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
