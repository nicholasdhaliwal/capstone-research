"""
data/scrape/pacer.py

PACER / RECAP supplemental scraper.

PACER (Public Access to Court Electronic Records) requires a paid account
and per-page fees. This module uses the RECAP archive — a free mirror of
PACER documents maintained by the Free Law Project — to retrieve documents
without incurring PACER charges.

RECAP API docs: https://free.law/recap/
CourtListener RECAP endpoint: https://www.courtlistener.com/help/api/rest/#recap-query

Two modes:
    recap_search:  Search the RECAP archive for dockets matching the query.
                   Returns docket entries with links to available documents.

    fetch_docket:  Given a docket ID, fetch all available opinion documents
                   from that docket and write them to disk.

This is supplemental to CourtListener — use it when CourtListener's
/search/ endpoint does not return enough opinions for your query, or
when you need documents from specific district courts not well-covered
by CourtListener's main index.

Usage:
    python -m data.scrape.pacer \
        --query "discrimination retaliation EEOC" \
        --max-dockets 200 \
        --output-dir data/raw/pacer/
"""

from __future__ import annotations

import os
import re
import json
import time
import logging
import argparse
from pathlib import Path
from typing import Optional, Iterator

import requests
import backoff
from tqdm import tqdm

logger = logging.getLogger(__name__)

RECAP_SEARCH_URL = "https://www.courtlistener.com/api/rest/v4/dockets/"
RECAP_DOC_URL = "https://www.courtlistener.com/api/rest/v4/recap-documents/"


class PACERRecapClient:
    """
    Fetches documents from the RECAP archive via CourtListener's API.

    Authentication: same CourtListener API token as the main scraper.
    Set COURTLISTENER_API_TOKEN environment variable or pass api_token arg.
    """

    def __init__(
        self,
        query: str = "employment discrimination Title VII",
        jurisdictions: Optional[list[str]] = None,
        date_from: str = "2000-01-01",
        date_to: str = "2024-12-31",
        max_dockets: int = 200,
        requests_per_second: float = 1.0,
        output_dir: str = "data/raw/pacer/",
        api_token: Optional[str] = None,
    ) -> None:
        self.query = query
        self.jurisdictions = jurisdictions or ["nyd", "nysd", "ca9"]  # PACER court codes
        self.date_from = date_from
        self.date_to = date_to
        self.max_dockets = max_dockets
        self.delay = 1.0 / max(requests_per_second, 0.1)
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)

        self.session = requests.Session()
        self.session.headers.update({"User-Agent": "concept-lm-research/0.1"})
        token = api_token or os.environ.get("COURTLISTENER_API_TOKEN")
        if token:
            self.session.headers.update({"Authorization": f"Token {token}"})
        else:
            logger.warning(
                "No API token set. RECAP requests may be rate-limited. "
                "Set COURTLISTENER_API_TOKEN environment variable."
            )

        self._fetched = 0

    def run(self) -> dict:
        failed = 0
        logger.info(f"Starting RECAP scrape: query='{self.query}'")

        for docket in tqdm(
            self._search_dockets(),
            total=self.max_dockets,
            desc="RECAP dockets",
        ):
            if self._fetched >= self.max_dockets:
                break
            docket_id = docket.get("id")
            if not docket_id:
                continue
            try:
                n = self._fetch_docket_documents(docket_id, docket)
                self._fetched += n
            except Exception as e:
                logger.warning(f"Failed docket {docket_id}: {e}")
                failed += 1
            time.sleep(self.delay)

        summary = {"fetched": self._fetched, "failed": failed, "output_dir": str(self.output_dir)}
        (self.output_dir / "manifest.json").write_text(json.dumps(summary, indent=2))
        return summary

    def _search_dockets(self) -> Iterator[dict]:
        """Paginate through dockets matching the query."""
        params = {
            "q": self.query,
            "date_filed__gte": self.date_from,
            "date_filed__lte": self.date_to,
            "format": "json",
        }
        if self.jurisdictions:
            params["court__id__in"] = ",".join(self.jurisdictions)

        url = RECAP_SEARCH_URL
        count = 0
        while url and count < self.max_dockets:
            resp = self._get(url, params=params if "dockets" in url else None)
            if resp is None:
                break
            data = resp.json()
            for item in data.get("results", []):
                if count >= self.max_dockets:
                    return
                yield item
                count += 1
            url = data.get("next")
            params = None
            time.sleep(self.delay)

    def _fetch_docket_documents(self, docket_id: int, docket_meta: dict) -> int:
        """
        Fetch opinion-type documents from a docket.
        Returns count of documents written.
        """
        params = {
            "docket_entry__docket": docket_id,
            "is_available": True,
            "format": "json",
        }
        resp = self._get(RECAP_DOC_URL, params=params)
        if resp is None:
            return 0

        written = 0
        for doc in resp.json().get("results", []):
            doc_id = doc.get("id")
            plain_text = doc.get("plain_text", "").strip()
            if not plain_text or len(plain_text) < 200:
                continue

            out_path = self.output_dir / f"recap_{doc_id}.txt"
            if out_path.exists():
                continue

            meta = {
                "doc_id": doc_id,
                "docket_id": docket_id,
                "case_name": docket_meta.get("case_name", ""),
                "court": docket_meta.get("court", ""),
                "date_filed": docket_meta.get("date_filed", ""),
                "source": "recap",
            }
            header = "".join(f"# {k}: {v}\n" for k, v in meta.items())
            out_path.write_text(header + "\n" + plain_text, encoding="utf-8")
            written += 1

        return written

    @backoff.on_exception(backoff.expo, requests.RequestException, max_tries=4)
    def _get(self, url: str, params: Optional[dict] = None) -> Optional[requests.Response]:
        try:
            resp = self.session.get(url, params=params, timeout=30)
            resp.raise_for_status()
            return resp
        except requests.HTTPError as e:
            if e.response.status_code == 429:
                wait = int(e.response.headers.get("Retry-After", 60))
                logger.warning(f"Rate limited; sleeping {wait}s")
                time.sleep(wait)
                raise
            logger.error(f"HTTP {e.response.status_code}: {url}")
            return None


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
    parser = argparse.ArgumentParser(description="Scrape PACER via RECAP archive")
    parser.add_argument("--query", default="employment discrimination Title VII")
    parser.add_argument("--jurisdictions", nargs="+", default=["nyd", "nysd"])
    parser.add_argument("--date-from", default="2000-01-01")
    parser.add_argument("--date-to", default="2024-12-31")
    parser.add_argument("--max-dockets", type=int, default=200)
    parser.add_argument("--requests-per-second", type=float, default=1.0)
    parser.add_argument("--output-dir", default="data/raw/pacer/")
    parser.add_argument("--api-token", default=None)
    args = parser.parse_args()

    client = PACERRecapClient(
        query=args.query,
        jurisdictions=args.jurisdictions,
        date_from=args.date_from,
        date_to=args.date_to,
        max_dockets=args.max_dockets,
        requests_per_second=args.requests_per_second,
        output_dir=args.output_dir,
        api_token=args.api_token,
    )
    print(json.dumps(client.run(), indent=2))


if __name__ == "__main__":
    main()
