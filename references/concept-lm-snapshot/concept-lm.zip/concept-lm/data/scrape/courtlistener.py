"""
data/scrape/courtlistener.py

CourtListener API client.

Fetches judicial opinions matching a configurable search query and writes
each opinion as a plain .txt file to the output directory.

API docs: https://www.courtlistener.com/help/api/rest/
Rate limit: 5,000 requests/day on the free tier. The client respects the
configured requests_per_second limit via the ratelimit library.

Usage (CLI):
    python -m data.scrape.courtlistener \
        --query "employment discrimination Title VII" \
        --jurisdictions ny ca-9 \
        --date-from 2000-01-01 \
        --date-to 2024-12-31 \
        --max-opinions 2000 \
        --output-dir data/raw/

Usage (Python):
    from data.scrape.courtlistener import CourtListenerClient
    from concept_lm.config import SearchConfig
    cfg = SearchConfig(query="age discrimination ADEA", max_opinions=500)
    client = CourtListenerClient(cfg)
    client.run()
"""

from __future__ import annotations

import os
import re
import json
import time
import logging
import argparse
from pathlib import Path
from typing import Optional, Iterator

import requests
import backoff
from tqdm import tqdm

logger = logging.getLogger(__name__)

COURTLISTENER_BASE = "https://www.courtlistener.com/api/rest/v4"
DEFAULT_PAGE_SIZE = 20


class CourtListenerClient:
    """
    Fetches opinions from CourtListener via the /search/ and /opinions/ endpoints.

    The search endpoint returns a paginated list of opinion clusters matching
    the query. For each cluster, we fetch the plain-text opinion body from
    the /opinions/ endpoint and write it to disk.
    """

    def __init__(
        self,
        query: str = "employment discrimination Title VII",
        jurisdictions: Optional[list[str]] = None,
        date_from: str = "2000-01-01",
        date_to: str = "2024-12-31",
        case_types: Optional[list[str]] = None,
        max_opinions: int = 2000,
        requests_per_second: float = 2.0,
        output_dir: str = "data/raw/",
        api_token: Optional[str] = None,
    ) -> None:
        self.query = query
        self.jurisdictions = jurisdictions or ["ny", "ca-9", "federal"]
        self.date_from = date_from
        self.date_to = date_to
        self.case_types = case_types or []
        self.max_opinions = max_opinions
        self.delay = 1.0 / max(requests_per_second, 0.1)
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)

        self.session = requests.Session()
        self.session.headers.update({"User-Agent": "concept-lm-research/0.1"})
        if api_token:
            self.session.headers.update({"Authorization": f"Token {api_token}"})
        elif os.environ.get("COURTLISTENER_API_TOKEN"):
            self.session.headers.update({
                "Authorization": f"Token {os.environ['COURTLISTENER_API_TOKEN']}"
            })

        self._fetched = 0
        self._skipped = 0

    def run(self) -> dict:
        """
        Main entry point. Searches and downloads opinions up to max_opinions.

        Returns:
            summary dict with counts of fetched, skipped, and failed opinions.
        """
        logger.info(f"Starting CourtListener scrape: query='{self.query}', max={self.max_opinions}")
        failed = 0

        for cluster in tqdm(
            self._search_clusters(),
            total=self.max_opinions,
            desc="Fetching opinions",
        ):
            if self._fetched >= self.max_opinions:
                break

            cluster_id = cluster.get("id") or cluster.get("cluster_id")
            if cluster_id is None:
                continue

            # Each cluster may have multiple opinion documents; take the first
            opinions_url = cluster.get("sub_opinions", [])
            if not opinions_url:
                self._skipped += 1
                continue

            for op_url in opinions_url[:1]:  # take first opinion in cluster
                op_id = self._extract_id(op_url)
                out_path = self.output_dir / f"{op_id}.txt"
                if out_path.exists():
                    self._skipped += 1
                    break

                try:
                    text = self._fetch_opinion_text(op_id)
                    if text and len(text.strip()) > 200:
                        meta = self._build_metadata(cluster, op_id)
                        self._write(out_path, text, meta)
                        self._fetched += 1
                    else:
                        self._skipped += 1
                except Exception as e:
                    logger.warning(f"Failed to fetch opinion {op_id}: {e}")
                    failed += 1

                time.sleep(self.delay)

        summary = {
            "fetched": self._fetched,
            "skipped": self._skipped,
            "failed": failed,
            "output_dir": str(self.output_dir),
        }
        logger.info(f"Scrape complete: {summary}")
        # Write manifest
        manifest_path = self.output_dir / "manifest.json"
        with open(manifest_path, "w") as f:
            json.dump(summary, f, indent=2)
        return summary

    def _search_clusters(self) -> Iterator[dict]:
        """
        Paginates through /search/?type=o results matching the query.
        Yields cluster dicts.
        """
        params = {
            "q": self.query,
            "type": "o",
            "order_by": "score desc",
            "filed_after": self.date_from,
            "filed_before": self.date_to,
            "format": "json",
        }
        if self.jurisdictions:
            params["court"] = " ".join(self.jurisdictions)
        if self.case_types:
            params["case_type"] = " ".join(self.case_types)

        url = f"{COURTLISTENER_BASE}/search/"
        fetched = 0

        while url and fetched < self.max_opinions:
            resp = self._get(url, params=params if "search" in url else None)
            if resp is None:
                break
            data = resp.json()
            results = data.get("results", [])
            for r in results:
                if fetched >= self.max_opinions:
                    return
                yield r
                fetched += 1
            url = data.get("next")
            params = None  # next URL already includes all params
            time.sleep(self.delay)

    @backoff.on_exception(backoff.expo, requests.RequestException, max_tries=4)
    def _get(self, url: str, params: Optional[dict] = None) -> Optional[requests.Response]:
        try:
            resp = self.session.get(url, params=params, timeout=30)
            resp.raise_for_status()
            return resp
        except requests.HTTPError as e:
            if e.response.status_code == 429:
                retry_after = int(e.response.headers.get("Retry-After", 60))
                logger.warning(f"Rate limited; sleeping {retry_after}s")
                time.sleep(retry_after)
                raise
            logger.error(f"HTTP error {e.response.status_code} for {url}")
            return None

    def _fetch_opinion_text(self, op_id: str) -> Optional[str]:
        """
        Fetch plain text for a single opinion by ID.
        Tries plain_text field first, falls back to html_with_citations stripped.
        """
        url = f"{COURTLISTENER_BASE}/opinions/{op_id}/"
        resp = self._get(url)
        if resp is None:
            return None
        data = resp.json()

        text = data.get("plain_text", "").strip()
        if not text:
            html = data.get("html_with_citations", "") or data.get("html", "") or ""
            text = self._strip_html(html).strip()
        return text or None

    @staticmethod
    def _strip_html(html: str) -> str:
        """Minimal HTML stripping without BeautifulSoup dependency."""
        text = re.sub(r"<[^>]+>", " ", html)
        text = re.sub(r"&[a-z]+;", " ", text)
        text = re.sub(r"\s+", " ", text)
        return text

    @staticmethod
    def _extract_id(url_or_str: str) -> str:
        """Extract numeric ID from a CourtListener resource URL."""
        m = re.search(r"/(\d+)/?$", str(url_or_str))
        return m.group(1) if m else str(url_or_str)

    @staticmethod
    def _build_metadata(cluster: dict, op_id: str) -> dict:
        return {
            "op_id": op_id,
            "cluster_id": cluster.get("id"),
            "case_name": cluster.get("case_name", ""),
            "date_filed": cluster.get("date_filed", ""),
            "court": cluster.get("court", ""),
            "docket_number": cluster.get("docket_number", ""),
            "source": "courtlistener",
        }

    @staticmethod
    def _write(path: Path, text: str, meta: dict) -> None:
        """Write opinion text with a metadata header comment."""
        header = "".join(f"# {k}: {v}\n" for k, v in meta.items())
        path.write_text(header + "\n" + text, encoding="utf-8")


# ── CLI ────────────────────────────────────────────────────────────────────────

def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
    parser = argparse.ArgumentParser(description="Scrape CourtListener opinions")
    parser.add_argument("--query", default="employment discrimination Title VII")
    parser.add_argument("--jurisdictions", nargs="+", default=["ny", "ca-9"])
    parser.add_argument("--date-from", default="2000-01-01")
    parser.add_argument("--date-to", default="2024-12-31")
    parser.add_argument("--max-opinions", type=int, default=2000)
    parser.add_argument("--requests-per-second", type=float, default=2.0)
    parser.add_argument("--output-dir", default="data/raw/")
    parser.add_argument("--api-token", default=None,
                        help="CourtListener API token (or set COURTLISTENER_API_TOKEN env var)")
    args = parser.parse_args()

    client = CourtListenerClient(
        query=args.query,
        jurisdictions=args.jurisdictions,
        date_from=args.date_from,
        date_to=args.date_to,
        max_opinions=args.max_opinions,
        requests_per_second=args.requests_per_second,
        output_dir=args.output_dir,
        api_token=args.api_token,
    )
    summary = client.run()
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
