"""
data/scrape/deduplicate.py

Deduplication and quality filtering of raw scraped opinion files.

Three-pass cleaning:
    1. Exact dedup: remove files with identical SHA-256 content hash.
    2. Near-dedup: remove files with >90% token-level Jaccard similarity
       (catches repeated boilerplate, duplicate opinions with minor edits).
    3. Quality filter: remove files that are too short, contain mostly
       non-English characters, or consist primarily of header/citation noise.

Output:
    Writes a cleaned copy to output_dir (default: data/raw_clean/).
    Writes a dedup_report.json summarizing what was removed and why.

Usage:
    python -m data.scrape.deduplicate \
        --input-dir data/raw/ \
        --output-dir data/raw_clean/ \
        --min-chars 1000 \
        --jaccard-threshold 0.9
"""

from __future__ import annotations

import os
import re
import json
import shutil
import hashlib
import logging
import argparse
from pathlib import Path
from collections import defaultdict
from typing import Optional

from tqdm import tqdm

logger = logging.getLogger(__name__)

# Minimum substantive text length after stripping metadata header
MIN_CHARS_DEFAULT = 1000

# Jaccard similarity threshold above which a document is considered a near-duplicate
JACCARD_THRESHOLD = 0.90

# Minimum fraction of ASCII printable characters required
MIN_ASCII_FRACTION = 0.85


def sha256(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def tokenize_for_jaccard(text: str) -> set[str]:
    """
    Split text into 4-character shingles for Jaccard estimation.
    More robust than word-level for legal text with heavy citation noise.
    """
    text = text.lower()
    text = re.sub(r"\s+", " ", text)
    return {text[i:i+4] for i in range(len(text) - 3)}


def jaccard(a: set, b: set) -> float:
    if not a or not b:
        return 0.0
    return len(a & b) / len(a | b)


def strip_metadata_header(text: str) -> str:
    """Remove the # key: value header lines written by the scrapers."""
    lines = text.splitlines()
    content_start = 0
    for i, line in enumerate(lines):
        if not line.startswith("#") and line.strip():
            content_start = i
            break
    return "\n".join(lines[content_start:])


def is_quality(text: str, min_chars: int = MIN_CHARS_DEFAULT) -> tuple[bool, str]:
    """
    Returns (passes, reason_if_failed).
    """
    body = strip_metadata_header(text)

    if len(body) < min_chars:
        return False, f"too_short ({len(body)} chars)"

    # ASCII fraction check (catches garbled PDFs or non-English documents)
    printable = sum(1 for c in body if 32 <= ord(c) < 127)
    ascii_frac = printable / max(len(body), 1)
    if ascii_frac < MIN_ASCII_FRACTION:
        return False, f"low_ascii ({ascii_frac:.2f})"

    # Minimum word count (opinions should have substantial prose)
    word_count = len(body.split())
    if word_count < 100:
        return False, f"too_few_words ({word_count})"

    return True, ""


def deduplicate(
    input_dir: str,
    output_dir: str,
    min_chars: int = MIN_CHARS_DEFAULT,
    jaccard_threshold: float = JACCARD_THRESHOLD,
) -> dict:
    """
    Full dedup + quality filter pipeline.

    Returns:
        report dict summarizing actions taken.
    """
    input_path = Path(input_dir)
    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)

    txt_files = sorted(input_path.rglob("*.txt"))
    logger.info(f"Found {len(txt_files)} raw files in {input_dir}")

    report = {
        "total_input": len(txt_files),
        "exact_dupes": 0,
        "near_dupes": 0,
        "quality_failures": defaultdict(int),
        "kept": 0,
    }

    # Pass 1: exact dedup by content hash
    seen_hashes: dict[str, Path] = {}
    unique_files: list[Path] = []

    for path in tqdm(txt_files, desc="Exact dedup"):
        text = path.read_text(encoding="utf-8", errors="replace")
        h = sha256(strip_metadata_header(text))
        if h in seen_hashes:
            report["exact_dupes"] += 1
            logger.debug(f"Exact dupe: {path.name} == {seen_hashes[h].name}")
        else:
            seen_hashes[h] = path
            unique_files.append(path)

    logger.info(f"After exact dedup: {len(unique_files)} files")

    # Pass 2: quality filter
    quality_files: list[tuple[Path, str]] = []  # (path, body_text)

    for path in tqdm(unique_files, desc="Quality filter"):
        text = path.read_text(encoding="utf-8", errors="replace")
        ok, reason = is_quality(text, min_chars=min_chars)
        if ok:
            quality_files.append((path, strip_metadata_header(text)))
        else:
            report["quality_failures"][reason] += 1

    logger.info(f"After quality filter: {len(quality_files)} files")

    # Pass 3: near-dedup via Jaccard on 4-grams
    # To keep this O(n) in memory, we compare each new document against a
    # random sample of previously accepted documents (MinHash would be ideal
    # for large corpora; this is sufficient for ~2000 documents).
    shingles_bank: list[set[str]] = []
    kept_files: list[Path] = []

    for path, body in tqdm(quality_files, desc="Near-dedup"):
        shingles = tokenize_for_jaccard(body[:5000])  # first 5000 chars is sufficient
        is_near_dupe = any(
            jaccard(shingles, ref) >= jaccard_threshold
            for ref in shingles_bank[-200:]  # compare against last 200 accepted
        )
        if is_near_dupe:
            report["near_dupes"] += 1
        else:
            shingles_bank.append(shingles)
            kept_files.append(path)

    logger.info(f"After near-dedup: {len(kept_files)} files")

    # Write output
    for path in tqdm(kept_files, desc="Writing output"):
        dest = output_path / path.name
        shutil.copy2(path, dest)
        report["kept"] += 1

    report["quality_failures"] = dict(report["quality_failures"])

    report_path = output_path / "dedup_report.json"
    with open(report_path, "w") as f:
        json.dump(report, f, indent=2)

    logger.info(f"Dedup complete. Kept {report['kept']}/{report['total_input']} files.")
    return report


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
    parser = argparse.ArgumentParser(description="Deduplicate and quality-filter scraped opinions")
    parser.add_argument("--input-dir", default="data/raw/")
    parser.add_argument("--output-dir", default="data/raw_clean/")
    parser.add_argument("--min-chars", type=int, default=MIN_CHARS_DEFAULT)
    parser.add_argument("--jaccard-threshold", type=float, default=JACCARD_THRESHOLD)
    args = parser.parse_args()

    report = deduplicate(
        args.input_dir,
        args.output_dir,
        min_chars=args.min_chars,
        jaccard_threshold=args.jaccard_threshold,
    )
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
