"""
concept_lm — Concept-Level Language Model for Structured Reasoning.

Top-level imports for convenience:

    from concept_lm import ConceptLM, ConceptLMConfig
"""

from concept_lm.config import ConceptLMConfig
from concept_lm.model.concept_lm import ConceptLM, LossBundle

__all__ = ["ConceptLM", "ConceptLMConfig", "LossBundle"]
__version__ = "0.1.0"
