"""
concept_lm/config.py

Central configuration dataclass for the Concept LM.
All hyperparameters live here. Instantiated from YAML via OmegaConf.

Usage:
    from concept_lm.config import ConceptLMConfig
    cfg = ConceptLMConfig.from_yaml("configs/model_small.yaml", "configs/train_default.yaml")
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional

import yaml


# ── Model ─────────────────────────────────────────────────────────────────────

@dataclass
class ModelConfig:
    # Token-level encoder / decoder
    d_token: int = 512
    n_token_layers: int = 4
    n_token_heads: int = 8
    token_dropout: float = 0.0

    # Concept space — kept at 1024 to match SONAR dimension (no projection needed)
    d_concept: int = 1024
    n_concept_layers: int = 6
    n_concept_heads: int = 8
    concept_dropout: float = 0.0

    # Boundary detector
    d_scan: int = 256
    boundary_threshold: float = 0.5
    train_temperature: float = 0.1

    # Compression
    target_ratio: int = 4
    max_concepts_per_doc: int = 512

    # Cross-attention decoder
    d_head: int = 64
    n_decoder_layers: int = 4

    # Vocabulary
    vocab_size: int = 50257        # GPT-2 tokenizer default
    max_seq_len: int = 2048        # per chunk

    # Document chunking (Option A: chunk-and-stitch with [DOC_SEP])
    chunk_size: int = 2048
    chunk_overlap: int = 128
    doc_sep_init_scale: float = 0.02

    # Runtime
    use_gradient_checkpointing: bool = True
    use_bf16: bool = True

    def validate(self) -> None:
        assert self.d_concept % self.n_concept_heads == 0, (
            f"d_concept ({self.d_concept}) must be divisible by n_concept_heads ({self.n_concept_heads})"
        )
        assert self.d_token % self.n_token_heads == 0, (
            f"d_token ({self.d_token}) must be divisible by n_token_heads ({self.n_token_heads})"
        )
        assert self.chunk_overlap < self.chunk_size, (
            "chunk_overlap must be less than chunk_size"
        )
        assert self.target_ratio >= 2, "target_ratio must be at least 2"


# ── Training ──────────────────────────────────────────────────────────────────

@dataclass
class TrainingConfig:
    total_steps: int = 100000
    warmup_steps: int = 1000
    phase1_steps: Optional[int] = None     # None → computed as int(0.2 * total_steps)

    batch_size: int = 8
    grad_accum: int = 4
    max_seq_len: int = 2048

    # Decoupled muP learning rates
    lr_token: float = 3e-4
    lr_concept: float = 1.5e-4
    lr_boundary: float = 3e-4
    lr_embed: float = 1e-4

    weight_decay: float = 0.1
    max_grad_norm: float = 1.0
    betas: List[float] = field(default_factory=lambda: [0.9, 0.95])

    # Loss weights
    w_ntp: float = 1.0
    w_align: float = 0.5
    w_next_concept: float = 0.5
    w_boundary_bce: float = 1.0
    w_balance_phase1: float = 0.01
    w_balance_phase2: float = 0.05

    # Checkpointing
    eval_every: int = 500
    save_every: int = 2000
    keep_last_n_checkpoints: int = 5
    output_dir: str = "checkpoints/"

    # Logging
    log_every: int = 100
    use_wandb: bool = False
    wandb_project: str = "concept-lm"
    wandb_run_name: Optional[str] = None

    # Data paths
    train_data_dir: str = "data/processed/train/"
    val_data_dir: str = "data/processed/val/"
    num_workers: int = 4

    seed: int = 42

    @property
    def effective_phase1_steps(self) -> int:
        if self.phase1_steps is not None:
            return self.phase1_steps
        return int(0.2 * self.total_steps)

    @property
    def effective_batch_size(self) -> int:
        return self.batch_size * self.grad_accum

    def validate(self) -> None:
        assert self.total_steps > self.warmup_steps, (
            "total_steps must exceed warmup_steps"
        )
        assert self.effective_phase1_steps < self.total_steps, (
            "phase1_steps must be less than total_steps"
        )


# ── Data ──────────────────────────────────────────────────────────────────────

@dataclass
class DataConfig:
    sonar_dim: int = 1024
    segmenter: str = "spacy"       # "spacy" or "sat"
    spacy_model: str = "en_core_web_sm"
    max_sentence_length: int = 512
    train_fraction: float = 0.85
    val_fraction: float = 0.10
    test_fraction: float = 0.05
    tokenizer: str = "gpt2"

    def validate(self) -> None:
        total = self.train_fraction + self.val_fraction + self.test_fraction
        assert abs(total - 1.0) < 1e-6, f"Split fractions must sum to 1.0, got {total}"
        assert self.segmenter in ("spacy", "sat"), (
            f"segmenter must be 'spacy' or 'sat', got {self.segmenter}"
        )


# ── Scrape ────────────────────────────────────────────────────────────────────

@dataclass
class SearchConfig:
    """
    Configures CourtListener / PACER scraping.
    Swap query and jurisdictions to collect any legal domain.
    """
    query: str = "employment discrimination Title VII"
    jurisdictions: List[str] = field(default_factory=lambda: ["ny", "ca-9", "federal"])
    date_from: str = "2000-01-01"
    date_to: str = "2024-12-31"
    case_types: List[str] = field(default_factory=list)
    max_opinions: int = 2000
    requests_per_second: float = 2.0
    output_dir: str = "data/raw/"


# ── Root config ───────────────────────────────────────────────────────────────

@dataclass
class ConceptLMConfig:
    model: ModelConfig = field(default_factory=ModelConfig)
    training: TrainingConfig = field(default_factory=TrainingConfig)
    data: DataConfig = field(default_factory=DataConfig)
    scrape: SearchConfig = field(default_factory=SearchConfig)

    def validate(self) -> None:
        self.model.validate()
        self.training.validate()
        self.data.validate()
        assert self.model.d_concept == self.data.sonar_dim, (
            f"model.d_concept ({self.model.d_concept}) must equal "
            f"data.sonar_dim ({self.data.sonar_dim}) — no projection layer at training time"
        )

    @classmethod
    def from_yaml(cls, *yaml_paths: str) -> "ConceptLMConfig":
        """
        Load config from one or more YAML files.
        Later files override earlier ones.

        Example:
            cfg = ConceptLMConfig.from_yaml(
                "configs/model_small.yaml",
                "configs/train_default.yaml"
            )
        """
        merged: dict = {}
        for path in yaml_paths:
            with open(path) as f:
                data = yaml.safe_load(f)
            if data:
                _deep_merge(merged, data)

        cfg = cls()
        if "model" in merged:
            cfg.model = _dict_to_dataclass(ModelConfig, merged["model"])
        if "training" in merged:
            cfg.training = _dict_to_dataclass(TrainingConfig, merged["training"])
        if "data" in merged:
            cfg.data = _dict_to_dataclass(DataConfig, merged["data"])
        if "scrape" in merged:
            cfg.scrape = _dict_to_dataclass(SearchConfig, merged["scrape"])

        cfg.validate()
        return cfg

    @classmethod
    def from_dict(cls, d: dict) -> "ConceptLMConfig":
        cfg = cls()
        if "model" in d:
            cfg.model = _dict_to_dataclass(ModelConfig, d["model"])
        if "training" in d:
            cfg.training = _dict_to_dataclass(TrainingConfig, d["training"])
        if "data" in d:
            cfg.data = _dict_to_dataclass(DataConfig, d["data"])
        if "scrape" in d:
            cfg.scrape = _dict_to_dataclass(SearchConfig, d["scrape"])
        cfg.validate()
        return cfg

    def to_dict(self) -> dict:
        import dataclasses
        return dataclasses.asdict(self)


# ── Helpers ───────────────────────────────────────────────────────────────────

def _deep_merge(base: dict, override: dict) -> dict:
    for k, v in override.items():
        if k in base and isinstance(base[k], dict) and isinstance(v, dict):
            _deep_merge(base[k], v)
        else:
            base[k] = v
    return base


def _dict_to_dataclass(cls, d: dict):
    import dataclasses
    fields = {f.name for f in dataclasses.fields(cls)}
    filtered = {k: v for k, v in d.items() if k in fields}
    return cls(**filtered)
