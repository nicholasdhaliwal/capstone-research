"""
concept_lm/inference/generate.py

Streaming generation with nucleus sampling.
Uses GenerationCache for efficient inference.
"""

from __future__ import annotations
from typing import Iterator, Optional
import torch
import torch.nn.functional as F
from transformers import GPT2Tokenizer

from concept_lm.model.concept_lm import ConceptLM
from concept_lm.inference.cache import GenerationCache


def generate(
    model: ConceptLM,
    prompt: str,
    tokenizer: GPT2Tokenizer,
    max_new_tokens: int = 256,
    temperature: float = 0.8,
    top_p: float = 0.9,
    device: str = "cuda",
) -> str:
    """
    Generate a completion for a text prompt.

    Args:
        model:          trained ConceptLM
        prompt:         input text string
        tokenizer:      GPT-2 tokenizer
        max_new_tokens: max tokens to generate
        temperature:    sampling temperature (lower = more deterministic)
        top_p:          nucleus sampling threshold
        device:         "cuda" or "cpu"

    Returns:
        generated text (prompt + completion)
    """
    model.eval()
    prompt_ids = tokenizer.encode(prompt, return_tensors="pt").to(device)  # (1, L)

    cache = GenerationCache(model.cfg.model)

    with torch.no_grad():
        logits = cache.prefill(model, prompt_ids)  # (1, vocab)

        for _ in range(max_new_tokens):
            next_id = _sample(logits, temperature, top_p)
            cache.generated_ids.append(next_id.item())

            if next_id.item() == tokenizer.eos_token_id:
                break

            # Re-run full forward for new token (simplified; full KV cache is future work)
            all_ids = torch.tensor([cache.generated_ids], device=device)
            if all_ids.shape[1] > model.cfg.model.max_seq_len:
                all_ids = all_ids[:, -model.cfg.model.max_seq_len:]

            logits_all, _ = model.forward(all_ids)
            logits = logits_all[:, -1, :]

    return tokenizer.decode(cache.generated_ids, skip_special_tokens=True)


def stream_generate(
    model: ConceptLM,
    prompt: str,
    tokenizer: GPT2Tokenizer,
    max_new_tokens: int = 256,
    temperature: float = 0.8,
    top_p: float = 0.9,
    device: str = "cuda",
) -> Iterator[str]:
    """
    Streaming generator — yields one decoded token string at a time.
    Suitable for interactive CLI or API streaming responses.
    """
    model.eval()
    prompt_ids = tokenizer.encode(prompt, return_tensors="pt").to(device)
    generated = prompt_ids.clone()

    with torch.no_grad():
        for _ in range(max_new_tokens):
            if generated.shape[1] > model.cfg.model.max_seq_len:
                logits, _ = model.forward_document(generated)
            else:
                logits, _ = model.forward(generated)

            next_id = _sample(logits[:, -1, :], temperature, top_p)
            generated = torch.cat([generated, next_id.unsqueeze(0)], dim=1)

            token_str = tokenizer.decode(next_id.tolist(), skip_special_tokens=True)
            yield token_str

            if next_id.item() == tokenizer.eos_token_id:
                break


def _sample(logits: torch.Tensor, temperature: float, top_p: float) -> torch.Tensor:
    """
    Nucleus (top-p) sampling.

    Args:
        logits: (1, vocab_size) or (vocab_size,)
        temperature: > 0
        top_p: in (0, 1]

    Returns:
        next_token_id: scalar tensor
    """
    if logits.dim() == 1:
        logits = logits.unsqueeze(0)

    scaled = logits / max(temperature, 1e-8)
    sorted_logits, sorted_idx = torch.sort(scaled, descending=True)
    cumulative = torch.cumsum(F.softmax(sorted_logits, dim=-1), dim=-1)

    # Remove tokens with cumulative probability above threshold
    remove = cumulative > top_p
    remove[:, 1:] = remove[:, :-1].clone()
    remove[:, 0] = False
    sorted_logits[remove] = float("-inf")

    probs = F.softmax(sorted_logits, dim=-1)
    sampled = torch.multinomial(probs, num_samples=1)
    return sorted_idx.gather(-1, sampled).squeeze(-1)
