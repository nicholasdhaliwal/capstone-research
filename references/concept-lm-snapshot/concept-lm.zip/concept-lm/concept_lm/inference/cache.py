"""
concept_lm/inference/cache.py

KV cache for efficient autoregressive generation.

Two caches:
    ConceptKVCache:  stores K/V tensors from the ConceptTransformer for all
                     completed concepts. A concept is "completed" when the
                     boundary detector fires at its final token.

    DecoderKVCache:  standard autoregressive KV cache for the token decoder.
                     Grows by one step per generated token.

Usage:
    cache = GenerationCache(model.cfg)
    # Prefill: encode the prompt
    cache.prefill(model, prompt_ids)
    # Generate: one token at a time
    for _ in range(max_new_tokens):
        next_id = cache.step(model)
        if next_id == EOS: break
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional
import torch
from concept_lm.config import ModelConfig


@dataclass
class ConceptKVCache:
    """
    Stores completed concept representations so the ConceptTransformer
    does not reprocess earlier concepts on each generation step.

    A concept is added to the cache when:
        - A new boundary is detected (b_t = 1) at some position t, signaling
          that the concept ending at t-1 is complete.

    The cache stores the final Z (enriched) representations, not the raw C vectors.
    """
    d_concept: int
    n_heads: int
    d_head: int
    n_layers: int
    device: torch.device

    # Completed concept Z vectors: (M_completed, d_concept)
    Z_completed: Optional[torch.Tensor] = field(default=None, repr=False)

    # KV tensors per layer: list of (K, V) where each is (n_heads, M_completed, d_head)
    layer_kvs: list[tuple[torch.Tensor, torch.Tensor]] = field(
        default_factory=list, repr=False
    )

    def n_completed(self) -> int:
        return 0 if self.Z_completed is None else self.Z_completed.shape[0]

    def add_concept(self, z: torch.Tensor) -> None:
        """
        Add one completed concept vector z: (d_concept,) to the cache.
        KV tensors are appended lazily during the next transformer forward.
        """
        z = z.unsqueeze(0)  # (1, d_concept)
        if self.Z_completed is None:
            self.Z_completed = z
        else:
            self.Z_completed = torch.cat([self.Z_completed, z], dim=0)

    def clear(self) -> None:
        self.Z_completed = None
        self.layer_kvs = []


@dataclass
class DecoderKVCache:
    """
    Standard autoregressive KV cache for the token decoder.
    Stores K and V tensors for all previously generated tokens.
    """
    d_token: int
    n_heads: int
    d_head: int
    n_layers: int
    device: torch.device

    # Per-layer: (K, V) each (n_heads, L_generated, d_head)
    layer_kvs: list[tuple[torch.Tensor, torch.Tensor]] = field(
        default_factory=list, repr=False
    )

    def n_tokens(self) -> int:
        if not self.layer_kvs:
            return 0
        return self.layer_kvs[0][0].shape[-2]

    def clear(self) -> None:
        self.layer_kvs = []


class GenerationCache:
    """
    Manages both caches and exposes the prefill + step interface.
    """

    def __init__(self, cfg: ModelConfig) -> None:
        self.cfg = cfg
        device = torch.device("cpu")  # set properly by prefill()

        self.concept_cache = ConceptKVCache(
            d_concept=cfg.d_concept,
            n_heads=cfg.n_concept_heads,
            d_head=cfg.d_head,
            n_layers=cfg.n_concept_layers,
            device=device,
        )
        self.decoder_cache = DecoderKVCache(
            d_token=cfg.d_token,
            n_heads=cfg.n_token_heads,
            d_head=cfg.d_head,
            n_layers=cfg.n_decoder_layers,
            device=device,
        )

        self.current_segment_H: list[torch.Tensor] = []  # token H states in current concept
        self.generated_ids: list[int] = []

    def clear(self) -> None:
        self.concept_cache.clear()
        self.decoder_cache.clear()
        self.current_segment_H = []
        self.generated_ids = []

    def prefill(self, model, prompt_ids: torch.Tensor) -> torch.Tensor:
        """
        Process the full prompt, populate both caches, return logits for last token.

        Args:
            model:      ConceptLM instance
            prompt_ids: (1, L) prompt token IDs

        Returns:
            logits: (1, vocab_size) logits for the next token prediction
        """
        self.clear()
        device = prompt_ids.device
        self.concept_cache.device = device
        self.decoder_cache.device = device

        # Encode prompt
        H = model.encoder(prompt_ids)  # (1, L, d_token)
        L = H.shape[1]

        # Detect boundaries across the prompt
        b, p, _ = model.boundary(H, training=False)  # (1, L)

        # Pool prompt into concepts
        C, C_mask, seg_maps = model.pooler(H, b)  # (1, M, d_concept)

        # Run concept transformer over all prompt concepts
        Z, _ = model.concept_transformer(C, C_mask)

        # Store completed concepts in cache
        M = (~C_mask[0]).sum().item()
        for m in range(M):
            self.concept_cache.add_concept(Z[0, m])

        # Get logits for last token using decoder
        logits = model.decoder(H, Z, seg_maps, C_mask)  # (1, L, vocab)
        self.generated_ids = prompt_ids[0].tolist()

        return logits[0, -1:, :]  # (1, vocab)
