"""
concept_lm/model/encoder.py

TokenEncoder: converts input token IDs into contextual hidden representations H.

H = E(x)  where x is (B, L) token IDs and H is (B, L, d_token)

Architecture: causal Transformer with pre-norm (more stable than post-norm).
Gradient checkpointing is enabled when cfg.use_gradient_checkpointing is True.

At inference, this module runs once over the full tokenized input (or chunk).
Its output H feeds both the BoundaryDetector and (as a residual) the
CrossAttentionDecoder's second attention stream.
"""

import torch
import torch.nn as nn
from torch.utils.checkpoint import checkpoint

from concept_lm.config import ModelConfig


class TokenEncoder(nn.Module):
    def __init__(self, cfg: ModelConfig) -> None:
        super().__init__()
        self.cfg = cfg
        self.d_token = cfg.d_token

        self.token_embed = nn.Embedding(cfg.vocab_size, cfg.d_token)
        self.pos_embed = nn.Embedding(cfg.max_seq_len, cfg.d_token)

        # [DOC_SEP] concept vector — a learned parameter inserted between
        # concept sequences from adjacent chunks of the same document.
        # Initialized from a small normal distribution.
        self.doc_sep = nn.Parameter(
            torch.randn(cfg.d_concept) * cfg.doc_sep_init_scale
        )

        encoder_layer = nn.TransformerEncoderLayer(
            d_model=cfg.d_token,
            nhead=cfg.n_token_heads,
            dim_feedforward=cfg.d_token * 4,
            dropout=cfg.token_dropout,
            batch_first=True,
            norm_first=True,   # pre-norm: more stable gradient flow
            activation="gelu",
        )
        self.transformer = nn.TransformerEncoder(
            encoder_layer,
            num_layers=cfg.n_token_layers,
            enable_nested_tensor=False,  # required for gradient checkpointing
        )
        self.out_norm = nn.LayerNorm(cfg.d_token)
        self._use_checkpoint = cfg.use_gradient_checkpointing

    def forward(self, input_ids: torch.Tensor) -> torch.Tensor:
        """
        Args:
            input_ids: (B, L) integer token IDs, L <= cfg.max_seq_len

        Returns:
            H: (B, L, d_token) contextual token representations
        """
        B, L = input_ids.shape
        assert L <= self.cfg.max_seq_len, (
            f"Sequence length {L} exceeds max_seq_len {self.cfg.max_seq_len}. "
            "Use the chunking strategy in concept_lm.py for full documents."
        )

        positions = torch.arange(L, device=input_ids.device).unsqueeze(0)  # (1, L)
        x = self.token_embed(input_ids) + self.pos_embed(positions)        # (B, L, d_token)

        # Causal mask: token t cannot attend to position t+1 onward
        causal_mask = nn.Transformer.generate_square_subsequent_mask(
            L, device=input_ids.device, dtype=x.dtype
        )

        if self._use_checkpoint and self.training:
            # Gradient checkpointing trades compute for memory.
            # Wrap the transformer call so activations are recomputed on backward.
            def _run(x, mask):
                return self.transformer(x, mask=mask, is_causal=True)
            H = checkpoint(_run, x, causal_mask, use_reentrant=False)
        else:
            H = self.transformer(x, mask=causal_mask, is_causal=True)

        return self.out_norm(H)   # (B, L, d_token)

    def encode_chunks(
        self,
        input_ids: torch.Tensor,
        chunk_size: int,
        chunk_overlap: int,
    ) -> tuple[torch.Tensor, list[tuple[int, int]]]:
        """
        Encode a long sequence by splitting into overlapping chunks.

        Returns:
            H_full: (1, L, d_token) — reconstructed full-length hidden states
                    with averaged overlap regions
            chunk_spans: list of (start, end) token index pairs for each chunk
        """
        B, L = input_ids.shape
        assert B == 1, "encode_chunks currently operates on single sequences (B=1)"

        stride = chunk_size - chunk_overlap
        starts = list(range(0, L, stride))
        # Ensure last chunk covers the end
        if starts[-1] + chunk_size < L:
            starts.append(L - chunk_size)

        H_accum = torch.zeros(1, L, self.d_token, device=input_ids.device, dtype=input_ids.dtype if False else torch.float32)
        count = torch.zeros(1, L, 1, device=input_ids.device)
        chunk_spans = []

        for s in starts:
            e = min(s + chunk_size, L)
            chunk_ids = input_ids[:, s:e]
            H_chunk = self.forward(chunk_ids)   # (1, e-s, d_token)
            H_accum[:, s:e] += H_chunk.float()
            count[:, s:e] += 1
            chunk_spans.append((s, e))

        H_full = (H_accum / count.clamp(min=1)).to(H_chunk.dtype)
        return H_full, chunk_spans
