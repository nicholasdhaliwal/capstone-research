"""
concept_lm/model/pooler.py

ConceptPooler: converts token representations within each detected segment
into a single concept vector.

Two implementations:
    1. MeanPoolSegmentEncoder (default, lighter): mean-pools tokens within
       each segment, then applies a learned linear projection. Fast and
       memory-efficient. Loses intra-segment token ordering.

    2. TransformerSegmentEncoder (full): runs a small causal Transformer over
       the tokens within each segment and takes the representation at the
       final position (CLS-style). Preserves ordering and relative weight of
       tokens within the segment. More expressive but higher cost.

Select via cfg: pooler_type = "mean" | "transformer"

Output: C = [c_1, ..., c_M], each c_k in R^{d_concept}

Because different sequences produce different numbers of concepts, the
pooler returns a padded tensor and a mask rather than a list, enabling
efficient batched operations in the ConceptTransformer.
"""

from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F
from dataclasses import dataclass

from concept_lm.config import ModelConfig


class MeanPoolSegmentEncoder(nn.Module):
    """
    Mean-pools tokens within each segment.
    Simple and effective for most use cases.
    """

    def __init__(self, cfg: ModelConfig) -> None:
        super().__init__()
        self.W_up = nn.Linear(cfg.d_token, cfg.d_concept, bias=False)
        self.norm = nn.LayerNorm(cfg.d_concept)

    def encode_segment(self, segment_H: torch.Tensor) -> torch.Tensor:
        """
        Args:
            segment_H: (S, d_token) hidden states for one segment of S tokens

        Returns:
            c: (d_concept,) concept vector
        """
        c_raw = segment_H.mean(0)          # (d_token,)
        return self.norm(self.W_up(c_raw))  # (d_concept,)


class TransformerSegmentEncoder(nn.Module):
    """
    Runs a small Transformer over segment tokens and reads off the last
    position as the concept representation. Preserves token ordering within
    each concept. More expressive than mean pooling.
    """

    def __init__(self, cfg: ModelConfig, n_layers: int = 2) -> None:
        super().__init__()
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=cfg.d_token,
            nhead=max(1, cfg.n_token_heads // 2),
            dim_feedforward=cfg.d_token * 2,
            dropout=0.0,
            batch_first=True,
            norm_first=True,
            activation="gelu",
        )
        self.transformer = nn.TransformerEncoder(encoder_layer, num_layers=n_layers)
        self.W_up = nn.Linear(cfg.d_token, cfg.d_concept, bias=False)
        self.norm = nn.LayerNorm(cfg.d_concept)

    def encode_segment(self, segment_H: torch.Tensor) -> torch.Tensor:
        """
        Args:
            segment_H: (S, d_token)

        Returns:
            c: (d_concept,)
        """
        x = segment_H.unsqueeze(0)                  # (1, S, d_token)
        out = self.transformer(x)                   # (1, S, d_token)
        c_raw = out[0, -1]                          # last position, (d_token,)
        return self.norm(self.W_up(c_raw))          # (d_concept,)


class ConceptPooler(nn.Module):
    """
    Segments H according to boundary indicators b, encodes each segment
    into a concept vector, and returns a padded batch tensor.

    Args:
        cfg:          ModelConfig
        encoder_type: "mean" or "transformer"
    """

    def __init__(self, cfg: ModelConfig, encoder_type: str = "transformer") -> None:
        super().__init__()
        self.cfg = cfg
        if encoder_type == "transformer":
            self.seg_encoder = TransformerSegmentEncoder(cfg)
        else:
            self.seg_encoder = MeanPoolSegmentEncoder(cfg)

    def forward(
        self,
        H: torch.Tensor,
        b: torch.Tensor,
    ) -> tuple[torch.Tensor, torch.Tensor, list[torch.Tensor]]:
        """
        Args:
            H: (B, L, d_token) token representations
            b: (B, L) binary boundary indicators

        Returns:
            C_padded:   (B, M_max, d_concept) padded concept sequences
            C_mask:     (B, M_max) bool mask, True where padding
            seg_maps:   list of B tensors, each (L,) mapping token → concept index
        """
        B, L, _ = H.shape
        concept_seqs: list[list[torch.Tensor]] = []
        seg_maps: list[torch.Tensor] = []

        for i in range(B):
            boundary_pos = b[i].nonzero(as_tuple=True)[0]
            if len(boundary_pos) == 0:
                boundary_pos = torch.tensor([0], device=H.device)

            starts = boundary_pos.tolist()
            ends = starts[1:] + [L]

            seg_map = torch.zeros(L, dtype=torch.long, device=H.device)
            concepts = []
            for k, (s, e) in enumerate(zip(starts, ends)):
                seg_map[s:e] = k
                c_k = self.seg_encoder.encode_segment(H[i, s:e])  # (d_concept,)
                concepts.append(c_k)

            concept_seqs.append(concepts)
            seg_maps.append(seg_map)

        # Pad concept sequences to M_max
        M_max = max(len(seq) for seq in concept_seqs)
        d = self.cfg.d_concept
        C_padded = torch.zeros(B, M_max, d, device=H.device, dtype=H.dtype)
        C_mask = torch.ones(B, M_max, dtype=torch.bool, device=H.device)  # True = padding

        for i, concepts in enumerate(concept_seqs):
            M_i = len(concepts)
            C_padded[i, :M_i] = torch.stack(concepts, dim=0)
            C_mask[i, :M_i] = False  # not padding

        return C_padded, C_mask, seg_maps

    def encode_single(
        self,
        H: torch.Tensor,
        b: torch.Tensor,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        """
        Convenience method for single-sequence inference (B=1).

        Returns:
            C:       (M, d_concept) concept sequence, unpadded
            seg_map: (L,) token → concept index
        """
        C_padded, C_mask, seg_maps = self.forward(H.unsqueeze(0), b.unsqueeze(0))
        M = (~C_mask[0]).sum().item()
        return C_padded[0, :M], seg_maps[0]
