"""
concept_lm/model/decoder.py

CrossAttentionDecoder: reconstructs token-level predictions from concept vectors.

Dual-source attention — two parallel attention streams per decoder layer:

    Stream 1 — Concept attention:
        Query: token hidden state h_t
        Key/Value: smoothed concept vectors Z (from ConceptTransformer)
        Causal mask: token t can only attend to concepts c_1...c_{j(t)}
                     where j(t) is the concept index for position t.
        Captures: high-level semantic context and reasoning structure.

    Stream 2 — Encoder attention:
        Query: token hidden state h_t
        Key/Value: raw encoder hidden states H (from TokenEncoder),
                   restricted to the same segment as token t.
        Captures: fine-grained details — entity names, numbers, citations —
                  that did not survive concept compression.

Both streams are projected to d_head dimensions, computed in parallel,
and their outputs are summed before the output projection.

The final token predictions are produced by a linear head over the vocabulary.
"""

import math
import torch
import torch.nn as nn
import torch.nn.functional as F

from concept_lm.config import ModelConfig


class DualSourceAttentionLayer(nn.Module):
    """
    One layer of dual-source cross-attention + FFN.
    Follows pre-norm convention for stability.
    """

    def __init__(self, cfg: ModelConfig) -> None:
        super().__init__()
        self.n_heads = cfg.n_token_heads
        self.d_head = cfg.d_head
        self.d_token = cfg.d_token
        self.d_concept = cfg.d_concept
        inner = self.n_heads * self.d_head

        # Self-attention on token sequence
        self.self_attn = nn.MultiheadAttention(
            embed_dim=cfg.d_token,
            num_heads=cfg.n_token_heads,
            dropout=0.0,
            batch_first=True,
        )

        # Stream 1: concept cross-attention
        self.WQ1 = nn.Linear(cfg.d_token, inner, bias=False)
        self.WK1 = nn.Linear(cfg.d_concept, inner, bias=False)
        self.WV1 = nn.Linear(cfg.d_concept, inner, bias=False)

        # Stream 2: encoder cross-attention
        self.WQ2 = nn.Linear(cfg.d_token, inner, bias=False)
        self.WK2 = nn.Linear(cfg.d_token, inner, bias=False)
        self.WV2 = nn.Linear(cfg.d_token, inner, bias=False)

        # Output projection (sum of both streams)
        self.WO = nn.Linear(inner, cfg.d_token, bias=False)

        # FFN
        self.ffn = nn.Sequential(
            nn.Linear(cfg.d_token, cfg.d_token * 4),
            nn.GELU(),
            nn.Linear(cfg.d_token * 4, cfg.d_token),
        )

        self.norm1 = nn.LayerNorm(cfg.d_token)  # before self-attention
        self.norm2 = nn.LayerNorm(cfg.d_token)  # before cross-attention
        self.norm3 = nn.LayerNorm(cfg.d_token)  # before FFN

    def forward(
        self,
        x: torch.Tensor,           # (B, L, d_token) current token representations
        Z: torch.Tensor,           # (B, M, d_concept) smoothed concept vectors
        H_enc: torch.Tensor,       # (B, L, d_token) raw encoder hidden states
        concept_mask: torch.Tensor, # (B, L, M) additive mask, -inf where masked
        encoder_mask: torch.Tensor, # (B, L, L) segment-local mask for stream 2
        causal_token_mask: torch.Tensor,  # (L, L) causal mask for self-attention
    ) -> torch.Tensor:
        B, L, _ = x.shape
        M = Z.shape[1]
        h = self.n_heads
        dh = self.d_head
        scale = math.sqrt(dh)

        # ── Self-attention ───────────────────────────────────────────────────
        x_norm = self.norm1(x)
        sa_out, _ = self.self_attn(
            x_norm, x_norm, x_norm,
            attn_mask=causal_token_mask,
            is_causal=True,
        )
        x = x + sa_out

        # ── Dual-source cross-attention ──────────────────────────────────────
        x_norm = self.norm2(x)

        # Stream 1: attend to concept vectors Z
        Q1 = self.WQ1(x_norm).view(B, L, h, dh).transpose(1, 2)   # (B, h, L, dh)
        K1 = self.WK1(Z).view(B, M, h, dh).transpose(1, 2)        # (B, h, M, dh)
        V1 = self.WV1(Z).view(B, M, h, dh).transpose(1, 2)        # (B, h, M, dh)

        attn1 = torch.matmul(Q1, K1.transpose(-2, -1)) / scale    # (B, h, L, M)
        # concept_mask: (B, L, M) → broadcast over heads
        attn1 = attn1 + concept_mask.unsqueeze(1)
        attn1 = F.softmax(attn1, dim=-1)
        out1 = torch.matmul(attn1, V1)                            # (B, h, L, dh)

        # Stream 2: attend to raw encoder hidden states H_enc
        Q2 = self.WQ2(x_norm).view(B, L, h, dh).transpose(1, 2)  # (B, h, L, dh)
        K2 = self.WK2(H_enc).view(B, L, h, dh).transpose(1, 2)   # (B, h, L, dh)
        V2 = self.WV2(H_enc).view(B, L, h, dh).transpose(1, 2)   # (B, h, L, dh)

        attn2 = torch.matmul(Q2, K2.transpose(-2, -1)) / scale    # (B, h, L, L)
        attn2 = attn2 + encoder_mask.unsqueeze(1)
        attn2 = F.softmax(attn2, dim=-1)
        out2 = torch.matmul(attn2, V2)                            # (B, h, L, dh)

        # Sum both streams, project back to d_token
        out = (out1 + out2).transpose(1, 2).contiguous().view(B, L, -1)  # (B, L, h*dh)
        x = x + self.WO(out)

        # ── FFN ─────────────────────────────────────────────────────────────
        x = x + self.ffn(self.norm3(x))

        return x


class ConceptSmoother(nn.Module):
    """
    Lightweight depthwise 1D convolution over concept sequences.
    Smooths out hard boundary artifacts before decoding.
    """

    def __init__(self, cfg: ModelConfig) -> None:
        super().__init__()
        self.conv = nn.Conv1d(
            cfg.d_concept, cfg.d_concept,
            kernel_size=3, padding=1, groups=cfg.d_concept
        )
        self.norm = nn.LayerNorm(cfg.d_concept)

    def forward(self, Z: torch.Tensor) -> torch.Tensor:
        """
        Args:
            Z: (B, M, d_concept)
        Returns:
            Z_smooth: (B, M, d_concept)
        """
        Z_t = Z.transpose(1, 2)          # (B, d_concept, M)
        Z_t = self.conv(Z_t)             # (B, d_concept, M)
        return self.norm(Z_t.transpose(1, 2))  # (B, M, d_concept)


class CrossAttentionDecoder(nn.Module):
    """
    Full decoder: stacks DualSourceAttentionLayer blocks and produces
    next-token logits over the vocabulary.
    """

    def __init__(self, cfg: ModelConfig) -> None:
        super().__init__()
        self.cfg = cfg
        self.smoother = ConceptSmoother(cfg)
        self.layers = nn.ModuleList([
            DualSourceAttentionLayer(cfg)
            for _ in range(cfg.n_decoder_layers)
        ])
        self.out_norm = nn.LayerNorm(cfg.d_token)
        self.lm_head = nn.Linear(cfg.d_token, cfg.vocab_size, bias=False)

    def _build_concept_mask(
        self,
        B: int,
        L: int,
        M: int,
        seg_maps: list[torch.Tensor],
        device: torch.device,
        dtype: torch.dtype,
    ) -> torch.Tensor:
        """
        Build additive concept attention mask: (B, L, M)
        Token t may attend to concept k only if k <= seg_map[t].
        Masked positions are set to -1e9 (additive mask convention).
        """
        mask = torch.zeros(B, L, M, device=device, dtype=dtype)
        concept_idx = torch.arange(M, device=device)  # (M,)
        for i in range(B):
            # seg_maps[i]: (L,)
            token_concept = seg_maps[i].unsqueeze(1)          # (L, 1)
            forbidden = (concept_idx.unsqueeze(0) > token_concept)  # (L, M)
            mask[i][forbidden] = -1e9
        return mask

    def _build_encoder_mask(
        self,
        B: int,
        L: int,
        seg_maps: list[torch.Tensor],
        device: torch.device,
        dtype: torch.dtype,
    ) -> torch.Tensor:
        """
        Build additive encoder attention mask: (B, L, L)
        Token t may attend to token s only if seg_map[s] == seg_map[t]
        (same segment — keeps fine-grained detail local to its concept).
        Positions in other segments are masked.
        """
        mask = torch.full((B, L, L), -1e9, device=device, dtype=dtype)
        for i in range(B):
            sm = seg_maps[i]  # (L,)
            # Allow attention within same segment
            same_seg = (sm.unsqueeze(0) == sm.unsqueeze(1))  # (L, L)
            mask[i][same_seg] = 0.0
        return mask

    def forward(
        self,
        H: torch.Tensor,
        Z: torch.Tensor,
        seg_maps: list[torch.Tensor],
        C_mask: torch.Tensor | None = None,
    ) -> torch.Tensor:
        """
        Args:
            H:        (B, L, d_token) raw encoder hidden states
            Z:        (B, M, d_concept) concept transformer outputs
            seg_maps: list of B tensors, each (L,) token → concept index
            C_mask:   (B, M) padding mask from pooler (True = padding)

        Returns:
            logits: (B, L, vocab_size)
        """
        B, L, _ = H.shape
        M = Z.shape[1]
        device = H.device

        Z_smooth = self.smoother(Z)   # (B, M, d_concept)

        concept_mask = self._build_concept_mask(B, L, M, seg_maps, device, H.dtype)
        encoder_mask = self._build_encoder_mask(B, L, seg_maps, device, H.dtype)
        causal_token_mask = nn.Transformer.generate_square_subsequent_mask(
            L, device=device, dtype=H.dtype
        )

        x = H
        for layer in self.layers:
            x = layer(x, Z_smooth, H, concept_mask, encoder_mask, causal_token_mask)

        x = self.out_norm(x)
        return self.lm_head(x)   # (B, L, vocab_size)
