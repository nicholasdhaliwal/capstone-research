"""
concept_lm/model/boundary.py

BoundaryDetector: learns where concept boundaries occur in the token sequence.

Two training phases (set by trainer, not this module):
    Phase 1: receives soft sentence boundary targets → trained via BCE loss
             in addition to the indirect gradient from NTP + alignment losses.
    Phase 2: sentence supervision switched off → trains freely from the
             indirect gradient signal only. Load balancing weight is increased.

BoundaryDetector outputs:
    b: (B, L) binary boundary indicators — 1 where a new concept starts
    p: (B, L) boundary probabilities — used for BCE loss and load balancing

GlobalLoadBalancer: auxiliary loss that keeps the global boundary rate
    close to 1/R (one boundary per R tokens on average).
    Prevents degenerate solutions (all boundaries or no boundaries).
"""

import torch
import torch.nn as nn
import torch.nn.functional as F

from concept_lm.config import ModelConfig


class BoundaryDetector(nn.Module):
    """
    Scores boundary probability at each token position using cosine
    dissimilarity between adjacent token representations in a projected space.

        q_t = W_q * h_t  (normalized)
        k_t = W_k * h_t  (normalized)
        p_t = (1 - cos(q_{t-1}, k_t)) / 2     ∈ [0, 1]

    Position 0 always starts a new concept (p_0 = 1).

    Training:
        Probabilities are sharpened via temperature and sampled with Bernoulli.
        If sentence_boundaries are provided (Phase 1), a BCE loss is also
        computed against those targets and returned separately.

    Inference:
        Hard threshold: b_t = 1 if p_t >= boundary_threshold else 0.
    """

    def __init__(self, cfg: ModelConfig) -> None:
        super().__init__()
        self.cfg = cfg
        self.Wq = nn.Linear(cfg.d_token, cfg.d_scan, bias=False)
        self.Wk = nn.Linear(cfg.d_token, cfg.d_scan, bias=False)
        self.threshold = cfg.boundary_threshold
        self.temperature = cfg.train_temperature

        # Learnable bias on boundary logit — initialized to predict no boundary
        # (negative logit = low initial boundary rate, avoids early fragmentation)
        self.logit_bias = nn.Parameter(torch.tensor(-1.0))

    def forward(
        self,
        H: torch.Tensor,
        training: bool = True,
        sentence_boundaries: torch.Tensor | None = None,
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor | None]:
        """
        Args:
            H:                    (B, L, d_token) token representations
            training:             sample boundaries stochastically if True
            sentence_boundaries:  (B, L) float tensor in [0, 1], 1.0 where a
                                  sentence break was detected by SpaCy/SaT.
                                  None in Phase 2 and at inference.

        Returns:
            b:         (B, L) binary boundary indicators (detached)
            p:         (B, L) boundary probabilities (differentiable)
            bce_loss:  scalar BCE loss against sentence_boundaries, or None
        """
        B, L, _ = H.shape

        Q = F.normalize(self.Wq(H), dim=-1)   # (B, L, d_scan)
        K = F.normalize(self.Wk(H), dim=-1)   # (B, L, d_scan)

        # Cosine dissimilarity between position t-1 and t
        cos_sim = (Q[:, :-1] * K[:, 1:]).sum(-1)           # (B, L-1)
        dissimilarity = (1.0 - cos_sim) / 2.0              # (B, L-1), in [0, 1]

        # Convert to logit space, add learnable bias, then back to probability
        # This lets the model shift the operating point without changing Wq/Wk
        logit = torch.logit(dissimilarity.clamp(1e-6, 1 - 1e-6)) + self.logit_bias
        p_inner = torch.sigmoid(logit)                      # (B, L-1)

        # Position 0 always starts a concept
        p_first = torch.ones(B, 1, device=H.device, dtype=p_inner.dtype)
        p = torch.cat([p_first, p_inner], dim=1)            # (B, L)

        # Boundary sampling
        if training:
            p_sharp = torch.sigmoid((p - 0.5) / self.temperature)
            b = torch.bernoulli(p_sharp).detach()
        else:
            b = (p >= self.threshold).float()

        # Phase 1 BCE loss against known sentence boundaries
        bce_loss = None
        if sentence_boundaries is not None:
            # Only compute on positions 1..L (position 0 is trivially 1)
            bce_loss = F.binary_cross_entropy(
                p[:, 1:],
                sentence_boundaries[:, 1:].float(),
                reduction="mean",
            )

        return b, p, bce_loss


class GlobalLoadBalancer(nn.Module):
    """
    Auxiliary loss keeping the actual boundary rate close to 1/R.

    G = mean(p)   expected boundary rate
    F = mean(b)   actual boundary rate

    L_balance = (R / (R-1)) * [(R-1)*F*G + (1-F)*(1-G)] - 1

    This is minimized when F = G = 1/R.
    """

    def __init__(self, target_ratio: int) -> None:
        super().__init__()
        self.R = target_ratio

    def forward(self, b: torch.Tensor, p: torch.Tensor) -> torch.Tensor:
        """
        Args:
            b: (B, L) binary boundary indicators
            p: (B, L) boundary probabilities

        Returns:
            aux_loss: scalar
        """
        G = p.mean()
        F_val = b.float().mean()
        R = self.R
        return (R / (R - 1)) * ((R - 1) * F_val * G + (1 - F_val) * (1 - G)) - 1.0
