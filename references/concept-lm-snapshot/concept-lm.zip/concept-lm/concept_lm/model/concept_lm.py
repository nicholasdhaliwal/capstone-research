"""
concept_lm/model/concept_lm.py

ConceptLM: the full model. Wires all components together.

Forward pass (training):
    input_ids → TokenEncoder → H
    H → BoundaryDetector → (b, p, bce_loss)
    (H, b) → ConceptPooler → (C, C_mask, seg_maps)
    (C, C_mask) → ConceptTransformer → (Z, P)
    (H, Z, seg_maps) → CrossAttentionDecoder → logits

Returns logits and a LossBundle containing all individual losses.
The trainer applies the appropriate weighting per training phase.

Document handling (full opinions):
    Long documents are split into overlapping chunks of chunk_size tokens.
    Each chunk is encoded independently by the TokenEncoder.
    The resulting concept sequences are stitched together with a learned
    [DOC_SEP] concept vector inserted at chunk boundaries.
    The ConceptTransformer then sees the full stitched concept sequence.

Dry-run mode:
    Call ConceptLM.dry_run() to verify the full forward pass on synthetic
    data without loading any real weights or data files.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import torch
import torch.nn as nn
import torch.nn.functional as F

from concept_lm.config import ConceptLMConfig, ModelConfig
from concept_lm.model.encoder import TokenEncoder
from concept_lm.model.boundary import BoundaryDetector, GlobalLoadBalancer
from concept_lm.model.pooler import ConceptPooler
from concept_lm.model.concept_transformer import ConceptTransformer
from concept_lm.model.decoder import CrossAttentionDecoder


@dataclass
class LossBundle:
    """
    All individual loss terms from one forward pass.
    The trainer applies phase-dependent weights and sums them.
    """
    ntp: torch.Tensor                           # next-token prediction
    align: torch.Tensor                         # concept alignment to SONAR
    next_concept: torch.Tensor                  # next-concept prediction
    balance: torch.Tensor                       # load balancing
    boundary_bce: Optional[torch.Tensor]        # sentence boundary supervision (Phase 1 only)

    def total(
        self,
        w_ntp: float = 1.0,
        w_align: float = 0.5,
        w_next_concept: float = 0.5,
        w_balance: float = 0.01,
        w_boundary_bce: float = 1.0,
    ) -> torch.Tensor:
        loss = w_ntp * self.ntp
        loss = loss + w_align * self.align
        loss = loss + w_next_concept * self.next_concept
        loss = loss + w_balance * self.balance
        if self.boundary_bce is not None:
            loss = loss + w_boundary_bce * self.boundary_bce
        return loss


class ConceptLM(nn.Module):
    def __init__(self, cfg: ConceptLMConfig) -> None:
        super().__init__()
        self.cfg = cfg
        mc = cfg.model

        self.encoder = TokenEncoder(mc)
        self.boundary = BoundaryDetector(mc)
        self.load_balancer = GlobalLoadBalancer(mc.target_ratio)
        self.pooler = ConceptPooler(mc, encoder_type="transformer")
        self.concept_transformer = ConceptTransformer(mc)
        self.decoder = CrossAttentionDecoder(mc)

        # Count parameters
        self._n_params = sum(p.numel() for p in self.parameters() if p.requires_grad)

    @property
    def n_params(self) -> int:
        return self._n_params

    # ── Single-chunk forward (sequences <= max_seq_len) ──────────────────────

    def forward(
        self,
        input_ids: torch.Tensor,
        labels: Optional[torch.Tensor] = None,
        sonar_targets: Optional[torch.Tensor] = None,
        sentence_boundaries: Optional[torch.Tensor] = None,
    ) -> tuple[torch.Tensor, Optional[LossBundle]]:
        """
        Args:
            input_ids:            (B, L) token IDs
            labels:               (B, L) token IDs for NTP loss, or None
            sonar_targets:        (B, M_max, d_concept) SONAR sentence embeddings
                                  for each concept position. Used for alignment
                                  and next-concept prediction losses. None at inference.
            sentence_boundaries:  (B, L) float in [0,1], 1.0 at sentence breaks.
                                  None in Phase 2 and at inference.

        Returns:
            logits:      (B, L, vocab_size)
            loss_bundle: LossBundle or None (None at inference)
        """
        # Stage 1: token encoding
        H = self.encoder(input_ids)                       # (B, L, d_token)

        # Stage 2: boundary detection
        b, p, bce_loss = self.boundary(
            H,
            training=self.training,
            sentence_boundaries=sentence_boundaries,
        )

        # Stage 3: load balancing loss
        balance_loss = self.load_balancer(b, p)

        # Stage 4: concept pooling
        C, C_mask, seg_maps = self.pooler(H, b)           # (B, M, d_concept)

        # Stage 5: concept reasoning
        Z, P = self.concept_transformer(C, C_mask)        # (B, M, d_concept) each

        # Stage 6: token decoding
        logits = self.decoder(H, Z, seg_maps, C_mask)     # (B, L, vocab_size)

        # Compute losses if in training mode
        if labels is None:
            return logits, None

        # NTP loss
        shift_logits = logits[:, :-1].contiguous().view(-1, self.cfg.model.vocab_size)
        shift_labels = labels[:, 1:].contiguous().view(-1)
        ntp_loss = F.cross_entropy(shift_logits, shift_labels, ignore_index=-100)

        # Alignment loss: concept vector c_k should match SONAR(sentence_k)
        # P_align is the concept vector produced by the pooler (from Z before prediction head)
        align_loss = self._alignment_loss(C, C_mask, sonar_targets)

        # Next-concept prediction loss: P_t should match SONAR(sentence_{t+1})
        next_concept_loss = self._next_concept_loss(P, C_mask, sonar_targets)

        loss_bundle = LossBundle(
            ntp=ntp_loss,
            align=align_loss,
            next_concept=next_concept_loss,
            balance=balance_loss,
            boundary_bce=bce_loss,
        )
        return logits, loss_bundle

    def _alignment_loss(
        self,
        C: torch.Tensor,
        C_mask: torch.Tensor,
        sonar_targets: Optional[torch.Tensor],
    ) -> torch.Tensor:
        """
        Cosine distance between pooler concept vectors and SONAR sentence embeddings.
        C: (B, M_max, d_concept), sonar_targets: (B, M_max, d_concept)
        """
        if sonar_targets is None:
            return torch.tensor(0.0, device=C.device)

        # Only compute over non-padded positions
        valid = ~C_mask  # (B, M_max) bool
        C_valid = C[valid]                          # (N_valid, d_concept)
        T_valid = sonar_targets[valid]              # (N_valid, d_concept)

        C_norm = F.normalize(C_valid, p=2, dim=-1)
        T_norm = F.normalize(T_valid, p=2, dim=-1)
        cosine_sim = (C_norm * T_norm).sum(-1)      # (N_valid,)
        return (1.0 - cosine_sim).mean()

    def _next_concept_loss(
        self,
        P: torch.Tensor,
        C_mask: torch.Tensor,
        sonar_targets: Optional[torch.Tensor],
    ) -> torch.Tensor:
        """
        P[:, t, :] should be close to sonar_targets[:, t+1, :].
        P is already L2-normalized from the ConceptTransformer.
        """
        if sonar_targets is None:
            return torch.tensor(0.0, device=P.device)

        B, M, d = P.shape
        if M < 2:
            return torch.tensor(0.0, device=P.device)

        # Shift: prediction at t targets SONAR embedding at t+1
        P_shifted = P[:, :-1]               # (B, M-1, d)  predictions
        T_shifted = sonar_targets[:, 1:]    # (B, M-1, d)  targets

        # Mask: valid if both position t and t+1 are non-padded
        valid = (~C_mask[:, :-1]) & (~C_mask[:, 1:])  # (B, M-1)
        if valid.sum() == 0:
            return torch.tensor(0.0, device=P.device)

        P_valid = P_shifted[valid]
        T_valid = T_shifted[valid]
        T_norm = F.normalize(T_valid, p=2, dim=-1)

        cosine_sim = (P_valid * T_norm).sum(-1)   # P already normalized
        return (1.0 - cosine_sim).mean()

    # ── Full-document forward (chunk-and-stitch, Option A) ───────────────────

    def forward_document(
        self,
        input_ids: torch.Tensor,
        labels: Optional[torch.Tensor] = None,
        sonar_targets: Optional[torch.Tensor] = None,
        sentence_boundaries: Optional[torch.Tensor] = None,
    ) -> tuple[torch.Tensor, Optional[LossBundle]]:
        """
        Handles documents of arbitrary length by chunking and stitching.
        B must be 1 for this method.

        Chunks are encoded independently. Their concept sequences are
        stitched with the learned [DOC_SEP] concept vector between them.
        The stitched sequence is processed by the ConceptTransformer once.

        Args:
            input_ids:  (1, L) — full document, any length
            labels, sonar_targets, sentence_boundaries: same as forward()
                but spanning the full document length.
        """
        assert input_ids.shape[0] == 1, "forward_document requires B=1"
        mc = self.cfg.model
        L = input_ids.shape[1]

        if L <= mc.chunk_size:
            return self.forward(input_ids, labels, sonar_targets, sentence_boundaries)

        # Chunk the document
        chunk_size = mc.chunk_size
        overlap = mc.chunk_overlap
        stride = chunk_size - overlap

        chunks = []
        starts = list(range(0, L, stride))
        if starts[-1] + chunk_size < L:
            starts.append(L - chunk_size)

        all_H = []
        all_concepts = []
        all_seg_maps = []
        chunk_boundaries = []  # (start_concept_idx, end_concept_idx) per chunk
        concept_offset = 0

        all_b = torch.zeros(1, L, device=input_ids.device)
        all_p = torch.zeros(1, L, device=input_ids.device)
        all_bce = []

        for s in starts:
            e = min(s + chunk_size, L)
            chunk_ids = input_ids[:, s:e]
            chunk_sb = sentence_boundaries[:, s:e] if sentence_boundaries is not None else None

            H_chunk = self.encoder(chunk_ids)                  # (1, e-s, d_token)
            b_chunk, p_chunk, bce_chunk = self.boundary(
                H_chunk, training=self.training, sentence_boundaries=chunk_sb
            )

            all_H.append((s, e, H_chunk))
            all_b[:, s:e] = b_chunk
            all_p[:, s:e] = p_chunk
            if bce_chunk is not None:
                all_bce.append(bce_chunk)

            C_chunk, _, seg_maps_chunk = self.pooler(H_chunk, b_chunk)
            M_chunk = C_chunk.shape[1]

            # Remap seg_maps to global concept indices
            global_seg_map = seg_maps_chunk[0] + concept_offset
            all_seg_maps.append((s, e, global_seg_map))

            chunk_boundaries.append((concept_offset, concept_offset + M_chunk))
            all_concepts.append(C_chunk.squeeze(0))  # (M_chunk, d_concept)
            concept_offset += M_chunk

        # Stitch: insert [DOC_SEP] between chunks
        doc_sep = self.encoder.doc_sep  # (d_concept,)
        stitched = []
        seg_sep_offsets = []
        sep_offset = 0
        for i, concepts in enumerate(all_concepts):
            stitched.append(concepts)
            sep_offset += concepts.shape[0]
            if i < len(all_concepts) - 1:
                stitched.append(doc_sep.unsqueeze(0))
                seg_sep_offsets.append(sep_offset)
                sep_offset += 1

        C_full = torch.cat(stitched, dim=0).unsqueeze(0)  # (1, M_total, d_concept)
        M_total = C_full.shape[1]
        C_mask_full = torch.zeros(1, M_total, dtype=torch.bool, device=input_ids.device)

        # Rebuild full H and full seg_map for the decoder
        H_full = torch.zeros(1, L, mc.d_token, device=input_ids.device, dtype=torch.float32)
        count = torch.zeros(1, L, 1, device=input_ids.device)
        for s, e, H_chunk in all_H:
            H_full[:, s:e] += H_chunk.float()
            count[:, s:e] += 1
        H_full = (H_full / count.clamp(min=1)).to(C_full.dtype)

        # Build global seg_map accounting for DOC_SEP insertions
        global_seg_map_full = torch.zeros(L, dtype=torch.long, device=input_ids.device)
        sep_adj = 0
        for i, (s, e, local_seg_map) in enumerate(all_seg_maps):
            # local_seg_map already has chunk-level offset; add sep adjustment
            global_seg_map_full[s:e] = local_seg_map + sep_adj
            if i < len(all_seg_maps) - 1:
                sep_adj += 1  # one DOC_SEP inserted after this chunk

        # Adjust for overlapping chunks (use latest chunk's assignment)
        # (already handled by sequential overwrite above)

        # ConceptTransformer over stitched sequence
        Z_full, P_full = self.concept_transformer(C_full, C_mask_full)

        # Decoder
        logits = self.decoder(H_full, Z_full, [global_seg_map_full], C_mask_full)

        if labels is None:
            return logits, None

        # Losses
        shift_logits = logits[:, :-1].contiguous().view(-1, mc.vocab_size)
        shift_labels = labels[:, 1:].contiguous().view(-1)
        ntp_loss = F.cross_entropy(shift_logits, shift_labels, ignore_index=-100)

        # For sonar_targets, only use the non-DOC_SEP positions
        align_loss = self._alignment_loss(C_full, C_mask_full, sonar_targets)
        next_concept_loss = self._next_concept_loss(P_full, C_mask_full, sonar_targets)
        balance_loss = self.load_balancer(all_b, all_p)
        bce_loss = torch.stack(all_bce).mean() if all_bce else None

        return logits, LossBundle(
            ntp=ntp_loss,
            align=align_loss,
            next_concept=next_concept_loss,
            balance=balance_loss,
            boundary_bce=bce_loss,
        )

    # ── Inference ─────────────────────────────────────────────────────────────

    @torch.no_grad()
    def generate(
        self,
        input_ids: torch.Tensor,
        max_new_tokens: int = 256,
        temperature: float = 1.0,
        top_p: float = 0.9,
    ) -> torch.Tensor:
        """
        Autoregressive generation. Uses forward_document for long contexts.
        For efficient inference with KV caching, use concept_lm/inference/generate.py.

        Args:
            input_ids:      (1, L) prompt token IDs
            max_new_tokens: maximum number of tokens to generate
            temperature:    sampling temperature
            top_p:          nucleus sampling threshold

        Returns:
            generated: (1, L + max_new_tokens) token IDs
        """
        self.eval()
        generated = input_ids.clone()

        for _ in range(max_new_tokens):
            if generated.shape[1] > self.cfg.model.max_seq_len:
                logits, _ = self.forward_document(generated)
            else:
                logits, _ = self.forward(generated)

            next_logits = logits[:, -1, :] / temperature  # (1, vocab)

            # Nucleus sampling
            sorted_logits, sorted_idx = torch.sort(next_logits, descending=True)
            cumulative_probs = torch.cumsum(F.softmax(sorted_logits, dim=-1), dim=-1)
            sorted_logits[cumulative_probs > top_p] = float("-inf")
            probs = F.softmax(sorted_logits, dim=-1)
            sampled_idx = torch.multinomial(probs, num_samples=1)
            next_token = sorted_idx.gather(-1, sampled_idx)  # (1, 1)

            generated = torch.cat([generated, next_token], dim=1)
            if (next_token == 50256).any():  # GPT-2 EOS
                break

        return generated

    # ── Utilities ─────────────────────────────────────────────────────────────

    @classmethod
    def dry_run(
        cls,
        config_paths: Optional[list[str]] = None,
        device: str = "cpu",
    ) -> None:
        """
        Run a full forward + backward pass on synthetic data to verify
        the pipeline end-to-end without any real data or checkpoints.

        Usage:
            ConceptLM.dry_run()
            ConceptLM.dry_run(["configs/model_small.yaml", "configs/train_default.yaml"])
        """
        from concept_lm.config import ConceptLMConfig

        if config_paths:
            cfg = ConceptLMConfig.from_yaml(*config_paths)
        else:
            cfg = ConceptLMConfig()

        mc = cfg.model
        print(f"\n{'='*60}")
        print(f"  DRY RUN — ConceptLM")
        print(f"  d_token={mc.d_token}  d_concept={mc.d_concept}")
        print(f"  n_concept_layers={mc.n_concept_layers}")
        print(f"  target_ratio={mc.target_ratio}")
        print(f"  device={device}")
        print(f"{'='*60}")

        model = cls(cfg).to(device)
        print(f"  Parameters: {model.n_params:,}")

        B, L = 2, 64
        M_max = L // mc.target_ratio

        input_ids = torch.randint(0, mc.vocab_size, (B, L), device=device)
        labels = input_ids.clone()

        # Synthetic SONAR targets (unit-normalized, same dimension as d_concept)
        sonar_targets = F.normalize(
            torch.randn(B, M_max, mc.d_concept, device=device), dim=-1
        )
        # Synthetic sentence boundaries (roughly every 8 tokens)
        sentence_boundaries = torch.zeros(B, L, device=device)
        sentence_boundaries[:, ::8] = 1.0

        model.train()
        logits, losses = model(
            input_ids,
            labels=labels,
            sonar_targets=sonar_targets,
            sentence_boundaries=sentence_boundaries,
        )

        total = losses.total(
            w_ntp=cfg.training.w_ntp,
            w_align=cfg.training.w_align,
            w_next_concept=cfg.training.w_next_concept,
            w_balance=cfg.training.w_balance_phase1,
            w_boundary_bce=cfg.training.w_boundary_bce,
        )
        total.backward()

        print(f"  logits shape:    {logits.shape}")
        print(f"  L_ntp:           {losses.ntp.item():.4f}")
        print(f"  L_align:         {losses.align.item():.4f}")
        print(f"  L_next_concept:  {losses.next_concept.item():.4f}")
        print(f"  L_balance:       {losses.balance.item():.4f}")
        if losses.boundary_bce is not None:
            print(f"  L_boundary_bce:  {losses.boundary_bce.item():.4f}")
        print(f"  L_total:         {total.item():.4f}")
        print(f"  Backward pass:   OK")

        # Test generation
        model.eval()
        prompt = torch.randint(0, mc.vocab_size, (1, 8), device=device)
        gen = model.generate(prompt, max_new_tokens=8)
        print(f"  generate output: {gen.shape}")
        print(f"\n  DRY RUN PASSED\n{'='*60}\n")
