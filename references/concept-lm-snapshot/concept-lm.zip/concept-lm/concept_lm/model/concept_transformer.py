"""
concept_lm/model/concept_transformer.py

ConceptTransformer: the reasoning backbone of the system.

Operates exclusively on concept vectors C = [c_1, ..., c_M] where M << L.
Because M is much smaller than the original token sequence length L, the
same compute budget buys deeper per-concept processing than is possible
with token-level Transformers.

Two outputs are produced per forward pass:

    Z:    (B, M, d_concept)  —  enriched concept representations.
                                 Used by the CrossAttentionDecoder to
                                 reconstruct tokens.

    P:    (B, M, d_concept)  —  next-concept predictions.
                                 P[:, t, :] is the model's prediction of
                                 c_{t+1} in SONAR space.
                                 Used by L_next_concept during training.
                                 Discarded at inference.

The prediction head is a single linear layer from d_concept → d_concept
followed by L2 normalization (to project onto the SONAR unit sphere where
cosine similarity is computed).
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.checkpoint import checkpoint

from concept_lm.config import ModelConfig


class ConceptTransformer(nn.Module):
    def __init__(self, cfg: ModelConfig) -> None:
        super().__init__()
        self.cfg = cfg

        encoder_layer = nn.TransformerEncoderLayer(
            d_model=cfg.d_concept,
            nhead=cfg.n_concept_heads,
            dim_feedforward=cfg.d_concept * 4,
            dropout=cfg.concept_dropout,
            batch_first=True,
            norm_first=True,
            activation="gelu",
        )
        self.transformer = nn.TransformerEncoder(
            encoder_layer,
            num_layers=cfg.n_concept_layers,
            enable_nested_tensor=False,
        )
        self.out_norm = nn.LayerNorm(cfg.d_concept)

        # Next-concept prediction head
        # Projects Z_t → predicted unit vector in SONAR space (c_{t+1})
        self.next_concept_head = nn.Sequential(
            nn.Linear(cfg.d_concept, cfg.d_concept, bias=False),
            nn.GELU(),
            nn.Linear(cfg.d_concept, cfg.d_concept, bias=False),
        )

        self._use_checkpoint = cfg.use_gradient_checkpointing

    def forward(
        self,
        C: torch.Tensor,
        C_mask: torch.Tensor | None = None,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        """
        Args:
            C:      (B, M, d_concept) padded concept sequences
            C_mask: (B, M) bool mask, True where padding (from ConceptPooler)
                    If None, all positions are treated as valid.

        Returns:
            Z: (B, M, d_concept) enriched concept representations
            P: (B, M, d_concept) next-concept predictions (L2-normalized)
               P[:, t, :] predicts c_{t+1}
        """
        B, M, _ = C.shape

        # Causal mask: concept t cannot attend to concept t+1 onward
        causal_mask = nn.Transformer.generate_square_subsequent_mask(
            M, device=C.device, dtype=C.dtype
        )

        if self._use_checkpoint and self.training:
            def _run(C, causal_mask):
                return self.transformer(
                    C,
                    mask=causal_mask,
                    src_key_padding_mask=C_mask,
                    is_causal=True,
                )
            Z = checkpoint(_run, C, causal_mask, use_reentrant=False)
        else:
            Z = self.transformer(
                C,
                mask=causal_mask,
                src_key_padding_mask=C_mask,
                is_causal=True,
            )

        Z = self.out_norm(Z)  # (B, M, d_concept)

        # Next-concept predictions — L2 normalized to live on the SONAR unit sphere
        P_raw = self.next_concept_head(Z)            # (B, M, d_concept)
        P = F.normalize(P_raw, p=2, dim=-1)          # (B, M, d_concept)

        return Z, P

    def forward_single(
        self,
        C: torch.Tensor,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        """
        Convenience method for single-sequence inference (no batch dim).

        Args:
            C: (M, d_concept)

        Returns:
            Z: (M, d_concept)
            P: (M, d_concept)
        """
        Z, P = self.forward(C.unsqueeze(0))
        return Z.squeeze(0), P.squeeze(0)
