"""
concept_lm/training/optimizer.py

Decoupled muP AdamW optimizer for ConceptLM.

Heterogeneous architectures with different-width components require
independent learning rate scaling per component. Using a single LR
causes the widest component to train with an oversized effective LR,
producing gradient explosions or instability.

Four parameter groups:
    token_level:   TokenEncoder + CrossAttentionDecoder (width = d_token)
    concept_level: ConceptTransformer + ConceptSmoother (width = d_concept)
    boundary:      BoundaryDetector + ConceptPooler    (width = d_scan)
    embeddings:    token_embed + pos_embed             (fixed LR per muP)
"""

from __future__ import annotations
import torch.optim as optim
from concept_lm.model.concept_lm import ConceptLM
from concept_lm.config import TrainingConfig


def build_optimizer(model: ConceptLM, cfg: TrainingConfig) -> optim.AdamW:
    token_params, concept_params, boundary_params, embed_params = [], [], [], []

    for name, param in model.named_parameters():
        if not param.requires_grad:
            continue
        if "token_embed" in name or "pos_embed" in name:
            embed_params.append(param)
        elif any(k in name for k in ("encoder.", "decoder.")):
            token_params.append(param)
        elif any(k in name for k in ("concept_transformer.", "smoother.")):
            concept_params.append(param)
        elif any(k in name for k in ("boundary.", "pooler.", "load_balancer.")):
            boundary_params.append(param)
        else:
            # doc_sep and any other params default to concept-level LR
            concept_params.append(param)

    param_groups = [
        {"params": token_params,   "lr": cfg.lr_token,   "name": "token_level"},
        {"params": concept_params, "lr": cfg.lr_concept, "name": "concept_level"},
        {"params": boundary_params,"lr": cfg.lr_boundary,"name": "boundary"},
        {"params": embed_params,   "lr": cfg.lr_embed,   "name": "embeddings"},
    ]

    return optim.AdamW(
        param_groups,
        weight_decay=cfg.weight_decay,
        betas=tuple(cfg.betas),
        eps=1e-8,
        fused=True,   # fused AdamW kernel for speed; falls back gracefully
    )
