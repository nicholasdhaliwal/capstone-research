"""
concept_lm/training/dataset.py

Dataset classes for ConceptLM training.

ConceptLMDataset:
    Each example is one legal opinion (or a chunk thereof).
    Returns:
        input_ids:            (L,) token IDs
        sonar_targets:        (M_max, 1024) SONAR sentence embeddings
        sentence_boundaries:  (L,) float, 1.0 at sentence starts
        sonar_valid_mask:     (M_max,) bool, True where SONAR target is valid

Data on disk (produced by data/preprocess/build_dataset.py):
    data/processed/{split}/
        {case_id}_tokens.npy          int32  (L,)
        {case_id}_sonar.npy           float32 (N_sentences, 1024)
        {case_id}_boundaries.npy      uint8  (L,)

DryRunDataset:
    Generates random tensors in the correct shapes.
    No disk access required.
"""

from __future__ import annotations

import os
import numpy as np
import torch
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
from pathlib import Path
from typing import Optional

from concept_lm.config import ConceptLMConfig


class ConceptLMDataset(Dataset):
    """
    Loads pre-processed examples from disk.
    Each example is one document stored as three aligned .npy files.
    """

    def __init__(
        self,
        data_dir: str,
        max_seq_len: int = 2048,
        max_concepts: int = 512,
        sonar_dim: int = 1024,
    ) -> None:
        self.data_dir = Path(data_dir)
        self.max_seq_len = max_seq_len
        self.max_concepts = max_concepts
        self.sonar_dim = sonar_dim

        # Find all cases that have all three required files
        token_files = sorted(self.data_dir.glob("*_tokens.npy"))
        self.case_ids = []
        for tf in token_files:
            case_id = tf.stem.replace("_tokens", "")
            sonar_f = self.data_dir / f"{case_id}_sonar.npy"
            boundary_f = self.data_dir / f"{case_id}_boundaries.npy"
            if sonar_f.exists() and boundary_f.exists():
                self.case_ids.append(case_id)

        if len(self.case_ids) == 0:
            raise RuntimeError(
                f"No valid examples found in {data_dir}. "
                "Run data/preprocess/build_dataset.py first."
            )

    def __len__(self) -> int:
        return len(self.case_ids)

    def __getitem__(self, idx: int) -> dict:
        case_id = self.case_ids[idx]

        tokens = np.load(self.data_dir / f"{case_id}_tokens.npy").astype(np.int64)
        sonar = np.load(self.data_dir / f"{case_id}_sonar.npy").astype(np.float32)
        boundaries = np.load(self.data_dir / f"{case_id}_boundaries.npy").astype(np.float32)

        # Truncate to max_seq_len
        tokens = tokens[:self.max_seq_len]
        boundaries = boundaries[:self.max_seq_len]
        L = len(tokens)

        # Pad sonar targets to max_concepts
        N_sent = min(len(sonar), self.max_concepts)
        sonar_padded = np.zeros((self.max_concepts, self.sonar_dim), dtype=np.float32)
        sonar_padded[:N_sent] = sonar[:N_sent]
        sonar_valid = np.zeros(self.max_concepts, dtype=bool)
        sonar_valid[:N_sent] = True

        return {
            "input_ids": torch.tensor(tokens, dtype=torch.long),
            "sonar_targets": torch.tensor(sonar_padded, dtype=torch.float32),
            "sentence_boundaries": torch.tensor(boundaries, dtype=torch.float32),
            "sonar_valid_mask": torch.tensor(sonar_valid, dtype=torch.bool),
            "case_id": case_id,
        }


class DryRunDataset(Dataset):
    """
    Generates random data in the correct tensor shapes.
    Use for verifying the pipeline before real data is ready.

    Usage:
        dataset = DryRunDataset(cfg, n_examples=32)
        loader  = DataLoader(dataset, batch_size=4, collate_fn=collate_fn)
    """

    def __init__(self, cfg: ConceptLMConfig, n_examples: int = 64) -> None:
        self.cfg = cfg
        self.n = n_examples
        self.L = cfg.model.max_seq_len
        self.M = cfg.model.max_concepts_per_doc
        self.d = cfg.model.d_concept
        self.V = cfg.model.vocab_size

    def __len__(self) -> int:
        return self.n

    def __getitem__(self, idx: int) -> dict:
        L = min(self.L, 128)  # short sequences for dry run speed
        tokens = torch.randint(0, self.V, (L,), dtype=torch.long)

        # Random SONAR targets (L2-normalized unit vectors)
        sonar_raw = torch.randn(self.M, self.d)
        sonar_targets = F.normalize(sonar_raw, p=2, dim=-1)
        sonar_valid = torch.ones(self.M, dtype=torch.bool)

        # Sentence boundaries approximately every 8 tokens
        boundaries = torch.zeros(L)
        boundaries[::8] = 1.0
        boundaries[0] = 1.0

        return {
            "input_ids": tokens,
            "sonar_targets": sonar_targets,
            "sentence_boundaries": boundaries,
            "sonar_valid_mask": sonar_valid,
            "case_id": f"dry_run_{idx}",
        }


def collate_fn(batch: list[dict]) -> dict:
    """
    Pads variable-length input_ids and sentence_boundaries to the
    longest sequence in the batch. sonar_targets are already padded
    to max_concepts by the dataset.
    """
    max_L = max(item["input_ids"].shape[0] for item in batch)

    padded_ids = []
    padded_boundaries = []

    for item in batch:
        L = item["input_ids"].shape[0]
        pad = max_L - L
        padded_ids.append(
            F.pad(item["input_ids"], (0, pad), value=0)
        )
        padded_boundaries.append(
            F.pad(item["sentence_boundaries"], (0, pad), value=0.0)
        )

    return {
        "input_ids": torch.stack(padded_ids),
        "sonar_targets": torch.stack([item["sonar_targets"] for item in batch]),
        "sentence_boundaries": torch.stack(padded_boundaries),
        "sonar_valid_mask": torch.stack([item["sonar_valid_mask"] for item in batch]),
        "case_ids": [item["case_id"] for item in batch],
    }


def build_dataloaders(
    cfg: ConceptLMConfig,
    dry_run: bool = False,
) -> tuple[DataLoader, DataLoader]:
    """
    Returns (train_loader, val_loader).
    Uses DryRunDataset if dry_run=True.
    """
    if dry_run:
        train_ds = DryRunDataset(cfg, n_examples=64)
        val_ds = DryRunDataset(cfg, n_examples=16)
    else:
        train_ds = ConceptLMDataset(
            cfg.training.train_data_dir,
            max_seq_len=cfg.model.max_seq_len,
            max_concepts=cfg.model.max_concepts_per_doc,
            sonar_dim=cfg.data.sonar_dim,
        )
        val_ds = ConceptLMDataset(
            cfg.training.val_data_dir,
            max_seq_len=cfg.model.max_seq_len,
            max_concepts=cfg.model.max_concepts_per_doc,
            sonar_dim=cfg.data.sonar_dim,
        )

    train_loader = DataLoader(
        train_ds,
        batch_size=cfg.training.batch_size,
        shuffle=True,
        num_workers=cfg.training.num_workers,
        collate_fn=collate_fn,
        pin_memory=True,
        drop_last=True,
    )
    val_loader = DataLoader(
        val_ds,
        batch_size=cfg.training.batch_size,
        shuffle=False,
        num_workers=cfg.training.num_workers,
        collate_fn=collate_fn,
        pin_memory=True,
    )
    return train_loader, val_loader
