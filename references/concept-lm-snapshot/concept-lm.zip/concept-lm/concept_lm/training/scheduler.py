"""
concept_lm/training/scheduler.py

Learning rate scheduler: linear warmup then cosine decay to 0.
Applied uniformly across all parameter groups (the muP scaling
is baked into the group-level LR, not the scheduler).
"""

from __future__ import annotations
import math
import torch.optim as optim
from concept_lm.config import TrainingConfig


def build_scheduler(optimizer: optim.Optimizer, cfg: TrainingConfig) -> optim.lr_scheduler.LambdaLR:
    def lr_lambda(step: int) -> float:
        if step < cfg.warmup_steps:
            return step / max(1, cfg.warmup_steps)
        progress = (step - cfg.warmup_steps) / max(1, cfg.total_steps - cfg.warmup_steps)
        return 0.5 * (1.0 + math.cos(math.pi * progress))

    return optim.lr_scheduler.LambdaLR(optimizer, lr_lambda)
