"""
concept_lm/training/trainer.py

Full training loop for ConceptLM.

Handles:
    - Phase 1 / Phase 2 transition (sentence supervision → free boundaries)
    - Decoupled muP optimizer with per-group learning rates
    - Gradient accumulation
    - Mixed precision (bf16)
    - Gradient clipping
    - Cosine LR schedule with warmup
    - Periodic evaluation on validation set
    - Checkpoint saving and loading
    - WandB logging (optional)
    - --dry-run mode (synthetic data, no disk access)
"""

from __future__ import annotations

import os
import time
import json
import torch
import torch.nn as nn
from torch.cuda.amp import GradScaler
from torch.utils.data import DataLoader
from pathlib import Path
from typing import Optional

from concept_lm.config import ConceptLMConfig
from concept_lm.model.concept_lm import ConceptLM
from concept_lm.training.losses import LossWeightSchedule
from concept_lm.training.optimizer import build_optimizer
from concept_lm.training.scheduler import build_scheduler
from concept_lm.training.dataset import build_dataloaders


class Trainer:
    def __init__(
        self,
        cfg: ConceptLMConfig,
        dry_run: bool = False,
        device: Optional[str] = None,
    ) -> None:
        self.cfg = cfg
        self.dry_run = dry_run

        # Device
        if device is None:
            self.device = "cuda" if torch.cuda.is_available() else "cpu"
        else:
            self.device = device

        # Seed
        torch.manual_seed(cfg.training.seed)

        # Model
        self.model = ConceptLM(cfg).to(self.device)
        if cfg.model.use_bf16 and self.device == "cuda":
            self.model = self.model.to(torch.bfloat16)

        # Optimizer + scheduler
        self.optimizer = build_optimizer(self.model, cfg.training)
        self.scheduler = build_scheduler(self.optimizer, cfg.training)

        # Loss weight schedule
        self.loss_schedule = LossWeightSchedule(cfg.training)

        # Data
        self.train_loader, self.val_loader = build_dataloaders(cfg, dry_run=dry_run)

        # State
        self.global_step = 0
        self.best_val_loss = float("inf")

        # Output directory
        self.out_dir = Path(cfg.training.output_dir)
        self.out_dir.mkdir(parents=True, exist_ok=True)

        # WandB
        self._wandb = None
        if cfg.training.use_wandb and not dry_run:
            try:
                import wandb
                run_name = cfg.training.wandb_run_name or f"clm-{int(time.time())}"
                self._wandb = wandb.init(
                    project=cfg.training.wandb_project,
                    name=run_name,
                    config=cfg.to_dict(),
                )
            except ImportError:
                print("WandB not installed; logging to stdout only.")

        print(f"\nTrainer initialized")
        print(f"  Model parameters: {self.model.n_params:,}")
        print(f"  Device:           {self.device}")
        print(f"  Phase 1 steps:    {self.loss_schedule.phase1_steps:,}")
        print(f"  Total steps:      {cfg.training.total_steps:,}")
        print(f"  Dry run:          {dry_run}")
        print(f"  Train examples:   {len(self.train_loader.dataset)}")
        print(f"  Val examples:     {len(self.val_loader.dataset)}\n")

    def train(self) -> None:
        cfg = self.cfg.training
        self.model.train()
        self.optimizer.zero_grad()

        accum_step = 0
        running = {k: 0.0 for k in ("total", "ntp", "align", "next_concept", "balance", "bce")}

        for batch in self._infinite_loader(self.train_loader):
            # Move batch to device
            batch = self._to_device(batch)

            # Determine whether boundary BCE supervision is active (Phase 1)
            in_phase1 = self.loss_schedule.in_phase1(self.global_step)
            sentence_boundaries = batch["sentence_boundaries"] if in_phase1 else None

            # Forward pass
            with torch.autocast(device_type=self.device, dtype=torch.bfloat16,
                                 enabled=(self.cfg.model.use_bf16 and self.device == "cuda")):
                logits, losses = self.model(
                    batch["input_ids"],
                    labels=batch["input_ids"],
                    sonar_targets=batch["sonar_targets"],
                    sentence_boundaries=sentence_boundaries,
                )

            # Weighted total loss
            weights = self.loss_schedule.get(self.global_step)
            total = losses.total(
                w_ntp=weights.w_ntp,
                w_align=weights.w_align,
                w_next_concept=weights.w_next_concept,
                w_balance=weights.w_balance,
                w_boundary_bce=weights.w_boundary_bce,
            )
            scaled = total / cfg.grad_accum
            scaled.backward()

            # Accumulate stats
            running["total"] += total.item()
            running["ntp"] += losses.ntp.item()
            running["align"] += losses.align.item()
            running["next_concept"] += losses.next_concept.item()
            running["balance"] += losses.balance.item()
            if losses.boundary_bce is not None:
                running["bce"] += losses.boundary_bce.item()
            accum_step += 1

            if accum_step < cfg.grad_accum:
                continue

            # Optimizer step
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), cfg.max_grad_norm)
            self.optimizer.step()
            self.scheduler.step()
            self.optimizer.zero_grad()
            accum_step = 0
            self.global_step += 1

            # Logging
            if self.global_step % cfg.log_every == 0:
                n = cfg.log_every
                log = {
                    "step": self.global_step,
                    "phase": 1 if in_phase1 else 2,
                    "loss/total": running["total"] / n,
                    "loss/ntp": running["ntp"] / n,
                    "loss/align": running["align"] / n,
                    "loss/next_concept": running["next_concept"] / n,
                    "loss/balance": running["balance"] / n,
                    "loss/bce": running["bce"] / n,
                    "lr/token": self.optimizer.param_groups[0]["lr"],
                    "lr/concept": self.optimizer.param_groups[1]["lr"],
                }
                self._log(log)
                running = {k: 0.0 for k in running}

            # Phase transition announcement
            if self.global_step == self.loss_schedule.phase1_steps:
                print(f"\n[Step {self.global_step}] Phase transition: "
                      f"sentence boundary supervision OFF, load balance weight increased.\n")

            # Evaluation
            if self.global_step % cfg.eval_every == 0:
                val_loss = self.evaluate()
                self.model.train()
                if val_loss < self.best_val_loss:
                    self.best_val_loss = val_loss
                    self._save_checkpoint("best")

            # Checkpoint
            if self.global_step % cfg.save_every == 0:
                self._save_checkpoint(f"step_{self.global_step}")
                self._prune_checkpoints()

            if self.global_step >= cfg.total_steps:
                print(f"\nTraining complete at step {self.global_step}.")
                self._save_checkpoint("final")
                break

    @torch.no_grad()
    def evaluate(self) -> float:
        self.model.eval()
        total_loss = 0.0
        n_batches = 0

        for batch in self.val_loader:
            batch = self._to_device(batch)
            with torch.autocast(device_type=self.device, dtype=torch.bfloat16,
                                 enabled=(self.cfg.model.use_bf16 and self.device == "cuda")):
                _, losses = self.model(
                    batch["input_ids"],
                    labels=batch["input_ids"],
                    sonar_targets=batch["sonar_targets"],
                    sentence_boundaries=None,  # no supervision during eval
                )
            total_loss += losses.ntp.item()
            n_batches += 1

        avg = total_loss / max(n_batches, 1)
        print(f"  [Eval step {self.global_step}] val_ntp_loss = {avg:.4f}")
        if self._wandb:
            self._wandb.log({"val/ntp_loss": avg, "step": self.global_step})
        return avg

    def _save_checkpoint(self, tag: str) -> None:
        path = self.out_dir / f"checkpoint_{tag}.pt"
        torch.save({
            "step": self.global_step,
            "model_state": self.model.state_dict(),
            "optimizer_state": self.optimizer.state_dict(),
            "scheduler_state": self.scheduler.state_dict(),
            "best_val_loss": self.best_val_loss,
            "config": self.cfg.to_dict(),
        }, path)
        print(f"  Checkpoint saved: {path}")

    def load_checkpoint(self, path: str) -> None:
        ckpt = torch.load(path, map_location=self.device)
        self.model.load_state_dict(ckpt["model_state"])
        self.optimizer.load_state_dict(ckpt["optimizer_state"])
        self.scheduler.load_state_dict(ckpt["scheduler_state"])
        self.global_step = ckpt["step"]
        self.best_val_loss = ckpt.get("best_val_loss", float("inf"))
        print(f"  Loaded checkpoint from {path} (step {self.global_step})")

    def _prune_checkpoints(self) -> None:
        keep = self.cfg.training.keep_last_n_checkpoints
        ckpts = sorted(self.out_dir.glob("checkpoint_step_*.pt"),
                       key=lambda p: int(p.stem.split("_")[-1]))
        for old in ckpts[:-keep]:
            old.unlink()

    def _to_device(self, batch: dict) -> dict:
        return {
            k: v.to(self.device) if isinstance(v, torch.Tensor) else v
            for k, v in batch.items()
        }

    def _log(self, log: dict) -> None:
        parts = [f"step {log['step']} | phase {log['phase']}"]
        parts.append(f"loss {log['loss/total']:.4f}")
        parts.append(f"ntp {log['loss/ntp']:.4f}")
        parts.append(f"align {log['loss/align']:.4f}")
        parts.append(f"next_c {log['loss/next_concept']:.4f}")
        parts.append(f"lr_tok {log['lr/token']:.2e}")
        print(" | ".join(parts))
        if self._wandb:
            self._wandb.log(log)

    @staticmethod
    def _infinite_loader(loader: DataLoader):
        while True:
            yield from loader
