"""
concept_lm/training/losses.py

All loss functions for ConceptLM training.

The trainer applies phase-dependent weights via LossWeightSchedule.
"""

from __future__ import annotations
from dataclasses import dataclass
import torch
from concept_lm.config import TrainingConfig


@dataclass
class LossWeights:
    w_ntp: float
    w_align: float
    w_next_concept: float
    w_balance: float
    w_boundary_bce: float


class LossWeightSchedule:
    """
    Returns the correct loss weights based on the current training step and phase.

    Phase 1 (step < phase1_steps):
        - Boundary BCE active at w_boundary_bce
        - Load balancing at w_balance_phase1

    Phase 2 (step >= phase1_steps):
        - Boundary BCE weight set to 0.0
        - Load balancing increased to w_balance_phase2
    """

    def __init__(self, cfg: TrainingConfig) -> None:
        self.cfg = cfg
        self.phase1_steps = cfg.effective_phase1_steps

    def get(self, step: int) -> LossWeights:
        in_phase1 = step < self.phase1_steps
        return LossWeights(
            w_ntp=self.cfg.w_ntp,
            w_align=self.cfg.w_align,
            w_next_concept=self.cfg.w_next_concept,
            w_balance=self.cfg.w_balance_phase1 if in_phase1 else self.cfg.w_balance_phase2,
            w_boundary_bce=self.cfg.w_boundary_bce if in_phase1 else 0.0,
        )

    def in_phase1(self, step: int) -> bool:
        return step < self.phase1_steps
