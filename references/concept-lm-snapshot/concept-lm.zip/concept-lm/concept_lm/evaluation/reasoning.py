"""
concept_lm/evaluation/reasoning.py

Legal reasoning structure evaluation.

Tests whether a trained model correctly predicts the logical outcome of
a legal argument given its preceding reasoning context.

Two evaluation tasks:

    Task 1 — Outcome prediction:
        Input:  concept sequence representing the body of an opinion
                (issue, standard, facts, analysis) with the final ruling withheld.
        Target: the ruling sentence (e.g. "court grants summary judgment").
        Metric: cosine similarity between the model's predicted next concept
                vector and the SONAR embedding of the actual ruling sentence.
        Interpretation: measures whether the model's concept-level reasoning
                        leads to the correct conclusion.

    Task 2 — Standard identification:
        Input:  a legal argument mentioning a specific legal standard
                (e.g. McDonnell Douglas, Faragher, Burlington Northern).
        Target: the sentence that applies the standard to the facts.
        Metric: whether the model's next-concept prediction is more similar
                to the correct application sentence than to a set of foil
                application sentences from other cases.
        Interpretation: measures whether the model correctly associates
                        legal standards with their appropriate application steps.
"""

from __future__ import annotations

import json
import logging
import random
from pathlib import Path
from typing import Optional

import numpy as np
import torch
import torch.nn.functional as F

logger = logging.getLogger(__name__)

# Known legal standards and associated keywords for standard identification task
LEGAL_STANDARDS = {
    "mcdonnell_douglas": [
        "McDonnell Douglas", "burden-shifting", "prima facie case",
        "legitimate non-discriminatory reason", "pretext"
    ],
    "faragher_ellerth": [
        "Faragher", "Ellerth", "affirmative defense", "supervisory harassment",
        "tangible employment action"
    ],
    "summary_judgment": [
        "summary judgment", "genuine dispute", "material fact",
        "no reasonable jury", "Rule 56"
    ],
}


class ReasoningEvaluator:
    def __init__(
        self,
        model,
        sonar_encoder=None,
        device: str = "cuda",
    ) -> None:
        self.model = model
        self.device = device
        self._sonar_encoder = sonar_encoder

    def _get_sonar_encoder(self):
        if self._sonar_encoder is None:
            try:
                from sonar.inference_pipelines.text import TextToEmbeddingModelPipeline
                self._sonar_encoder = TextToEmbeddingModelPipeline(
                    encoder="text_sonar_basic_encoder",
                    tokenizer="text_sonar_basic_encoder",
                    device=torch.device(self.device),
                )
            except ImportError:
                raise RuntimeError("SONAR required. pip install sonar-space fairseq2")
        return self._sonar_encoder

    def _sonar_encode(self, sentences: list[str]) -> np.ndarray:
        encoder = self._get_sonar_encoder()
        with torch.no_grad():
            embs = encoder.predict(sentences, source_lang="eng_Latn")
        return embs.cpu().float().numpy()

    @torch.no_grad()
    def outcome_prediction_score(
        self,
        context_ids: torch.Tensor,
        ruling_sentence: str,
        tokenizer,
    ) -> float:
        """
        Given a tokenized opinion body (without ruling), measure cosine
        similarity between the model's predicted next concept and the
        SONAR embedding of the actual ruling sentence.

        Args:
            context_ids:     (1, L) token IDs of opinion body (ruling withheld)
            ruling_sentence: the actual ruling sentence as a string
            tokenizer:       GPT-2 tokenizer

        Returns:
            cosine similarity score in [-1, 1], higher = better
        """
        self.model.eval()

        # Get target SONAR embedding
        ruling_emb = self._sonar_encode([ruling_sentence])[0]  # (1024,)
        ruling_norm = ruling_emb / max(np.linalg.norm(ruling_emb), 1e-8)

        # Run model over context to get concept sequence + next-concept prediction
        H = self.model.encoder(context_ids.to(self.device))
        b, p, _ = self.model.boundary(H, training=False)
        C, C_mask, _ = self.model.pooler(H, b)
        _, P = self.model.concept_transformer(C, C_mask)

        # Last predicted concept vector (prediction for the token after the context)
        M = (~C_mask[0]).sum().item()
        if M == 0:
            return 0.0

        last_pred = P[0, M - 1].cpu().float().numpy()  # (1024,)
        # P is already L2-normalized from ConceptTransformer

        return float(np.dot(last_pred, ruling_norm))

    @torch.no_grad()
    def standard_identification_score(
        self,
        context_ids: torch.Tensor,
        correct_application: str,
        foil_applications: list[str],
        tokenizer,
    ) -> dict:
        """
        Measures whether the model's next-concept prediction is more similar
        to the correct application than to foil applications.

        Args:
            context_ids:          (1, L) tokenized opinion context
            correct_application:  string — the correct next step in the argument
            foil_applications:    list of strings — incorrect application sentences

        Returns:
            dict with scores and rank of correct application
        """
        self.model.eval()

        all_sentences = [correct_application] + foil_applications
        all_embs = self._sonar_encode(all_sentences)  # (N, 1024)
        all_embs = all_embs / np.maximum(
            np.linalg.norm(all_embs, axis=1, keepdims=True), 1e-8
        )

        H = self.model.encoder(context_ids.to(self.device))
        b, _, _ = self.model.boundary(H, training=False)
        C, C_mask, _ = self.model.pooler(H, b)
        _, P = self.model.concept_transformer(C, C_mask)

        M = (~C_mask[0]).sum().item()
        if M == 0:
            return {"rank": len(all_sentences), "correct_score": 0.0}

        pred = P[0, M - 1].cpu().float().numpy()  # already normalized

        similarities = all_embs @ pred  # (N,)
        rank = int(np.argsort(-similarities).tolist().index(0)) + 1  # 1 = best

        return {
            "rank": rank,
            "correct_score": float(similarities[0]),
            "mean_foil_score": float(similarities[1:].mean()),
            "correct_wins": rank == 1,
        }

    def evaluate_from_dataset(
        self,
        segmented_dir: str,
        tokenizer,
        n_cases: int = 50,
        n_foils: int = 4,
        seed: int = 42,
    ) -> dict:
        """
        End-to-end evaluation on the segmented legal corpus.

        For each case, uses the first 80% of sentences as context and the
        last ruling-like sentence as the prediction target.

        Returns aggregate evaluation results.
        """
        seg_path = Path(segmented_dir)
        json_files = [f for f in sorted(seg_path.glob("*.json")) if "report" not in f.name]
        rng = random.Random(seed)
        rng.shuffle(json_files)
        selected = json_files[:n_cases]

        outcome_scores = []
        failed = 0

        for jf in selected:
            try:
                record = json.loads(jf.read_text())
                sentences = record.get("sentences", [])
                if len(sentences) < 5:
                    continue

                n_context = int(len(sentences) * 0.8)
                context_sents = sentences[:n_context]
                ruling = sentences[-1]

                context_text = " ".join(context_sents)
                ids = tokenizer.encode(context_text, return_tensors="pt",
                                       max_length=self.model.cfg.model.max_seq_len,
                                       truncation=True)

                score = self.outcome_prediction_score(ids, ruling, tokenizer)
                outcome_scores.append(score)

            except Exception as e:
                logger.debug(f"Failed on {jf.name}: {e}")
                failed += 1

        return {
            "n_evaluated": len(outcome_scores),
            "n_failed": failed,
            "mean_outcome_cosine": float(np.mean(outcome_scores)) if outcome_scores else 0.0,
            "median_outcome_cosine": float(np.median(outcome_scores)) if outcome_scores else 0.0,
            "frac_positive": float(np.mean([s > 0 for s in outcome_scores])) if outcome_scores else 0.0,
        }
