"""
concept_lm/evaluation/coherence.py

Semantic coherence evaluation for generated concept sequences.

Three coherence metrics:

    1. Inter-sentence cosine similarity (ISCS):
       Measures average cosine similarity between adjacent concept vectors
       in a generated sequence. High similarity = smooth transitions (good).
       Very high = repetitive (bad). Near-zero = incoherent jumps (bad).
       Target range: 0.4–0.8 for well-formed legal reasoning.

    2. Concept drift score:
       Measures how much the concept sequence drifts from the document topic.
       Computed as cosine similarity between each concept vector and the
       mean concept vector of the first 10% of the document (the "topic anchor").
       Severe drift in a legal opinion signals hallucinated tangents.

    3. Argument progression score:
       Specific to legal reasoning. Checks whether the model generates
       concepts in the expected logical order:
           issue identification → rule statement → rule application → conclusion
       Operationalized by checking cosine similarity between generated
       concept vectors and reference SONAR embeddings of template sentences
       representing each stage.
"""

from __future__ import annotations

import logging
from typing import Optional

import numpy as np
import torch
import torch.nn.functional as F

logger = logging.getLogger(__name__)

# Template sentences representing the four stages of IRAC legal reasoning
IRAC_TEMPLATES = {
    "issue": "The issue before the court is whether the plaintiff has established a prima facie case.",
    "rule":  "Under the applicable legal standard, the plaintiff must demonstrate each element of the claim.",
    "application": "Applying the rule to the facts of this case, the court finds that the evidence supports the following conclusion.",
    "conclusion": "For the foregoing reasons, the court grants the motion and enters judgment in favor of the defendant.",
}


class CoherenceEvaluator:
    def __init__(
        self,
        model,
        sonar_encoder=None,
        device: str = "cuda",
    ) -> None:
        self.model = model
        self.device = device
        self._sonar_encoder = sonar_encoder
        self._irac_embeddings: Optional[np.ndarray] = None  # (4, 1024) — lazy loaded

    def _get_sonar_encoder(self):
        if self._sonar_encoder is None:
            try:
                from sonar.inference_pipelines.text import TextToEmbeddingModelPipeline
                self._sonar_encoder = TextToEmbeddingModelPipeline(
                    encoder="text_sonar_basic_encoder",
                    tokenizer="text_sonar_basic_encoder",
                    device=torch.device(self.device),
                )
            except ImportError:
                raise RuntimeError("SONAR required. pip install sonar-space fairseq2")
        return self._sonar_encoder

    def _get_irac_embeddings(self) -> np.ndarray:
        if self._irac_embeddings is None:
            encoder = self._get_sonar_encoder()
            templates = list(IRAC_TEMPLATES.values())
            with torch.no_grad():
                embs = encoder.predict(templates, source_lang="eng_Latn")
            self._irac_embeddings = embs.cpu().float().numpy()
        return self._irac_embeddings

    def inter_sentence_cosine_similarity(
        self, concept_vectors: np.ndarray
    ) -> dict:
        """
        Args:
            concept_vectors: (M, d_concept) array of concept vectors

        Returns:
            dict with mean, std, and per-position scores
        """
        if len(concept_vectors) < 2:
            return {"mean": 0.0, "std": 0.0, "scores": []}

        # L2 normalize
        norms = np.linalg.norm(concept_vectors, axis=1, keepdims=True)
        normed = concept_vectors / np.maximum(norms, 1e-8)

        # Adjacent cosine similarities
        scores = (normed[:-1] * normed[1:]).sum(axis=1).tolist()
        return {
            "mean": float(np.mean(scores)),
            "std": float(np.std(scores)),
            "min": float(np.min(scores)),
            "max": float(np.max(scores)),
            "scores": scores,
        }

    def concept_drift_score(
        self, concept_vectors: np.ndarray, anchor_fraction: float = 0.1
    ) -> dict:
        """
        Measures how much the sequence drifts from its topic anchor.

        Args:
            concept_vectors:  (M, d_concept)
            anchor_fraction:  fraction of vectors used as topic anchor

        Returns:
            dict with mean drift and per-position drift scores
        """
        M = len(concept_vectors)
        if M < 4:
            return {"mean_similarity_to_anchor": 1.0, "drift_detected": False}

        n_anchor = max(1, int(M * anchor_fraction))
        anchor = concept_vectors[:n_anchor].mean(axis=0, keepdims=True)  # (1, d)

        # Normalize
        anchor = anchor / max(np.linalg.norm(anchor), 1e-8)
        norms = np.linalg.norm(concept_vectors, axis=1, keepdims=True)
        normed = concept_vectors / np.maximum(norms, 1e-8)

        similarities = (normed * anchor).sum(axis=1)  # (M,)
        mean_sim = float(similarities.mean())
        late_sim = float(similarities[M // 2:].mean()) if M > 4 else mean_sim

        # Drift detected if later half has significantly lower similarity to anchor
        drift_detected = (mean_sim - late_sim) > 0.2

        return {
            "mean_similarity_to_anchor": mean_sim,
            "late_half_similarity": late_sim,
            "drift_detected": drift_detected,
        }

    def argument_progression_score(
        self, concept_vectors: np.ndarray
    ) -> dict:
        """
        Checks whether concepts follow IRAC argument structure.
        Computes cosine similarity of each concept to each IRAC stage template
        and evaluates whether the ordering is monotonically progressing.

        Returns:
            dict with per-stage peak positions and a progression score (0-1)
        """
        irac = self._get_irac_embeddings()  # (4, 1024)

        norms_cv = np.linalg.norm(concept_vectors, axis=1, keepdims=True)
        normed_cv = concept_vectors / np.maximum(norms_cv, 1e-8)

        norms_ir = np.linalg.norm(irac, axis=1, keepdims=True)
        normed_ir = irac / np.maximum(norms_ir, 1e-8)

        # Similarity of each concept to each IRAC stage: (M, 4)
        sim_matrix = normed_cv @ normed_ir.T

        # Peak position for each stage
        peak_positions = sim_matrix.argmax(axis=0)  # (4,)
        stage_names = list(IRAC_TEMPLATES.keys())

        # Progression score: fraction of stages in correct order
        n_correct = sum(
            1 for i in range(len(peak_positions) - 1)
            if peak_positions[i] <= peak_positions[i + 1]
        )
        progression_score = n_correct / max(len(peak_positions) - 1, 1)

        return {
            "stage_peak_positions": {
                stage_names[i]: int(peak_positions[i]) for i in range(4)
            },
            "progression_score": float(progression_score),
            "n_concepts": len(concept_vectors),
        }

    @torch.no_grad()
    def evaluate_generation(
        self,
        generated_concept_vectors: torch.Tensor,
        compute_irac: bool = True,
    ) -> dict:
        """
        Full coherence evaluation for a generated concept sequence.

        Args:
            generated_concept_vectors: (M, d_concept) tensor
            compute_irac: whether to compute argument progression (requires SONAR)

        Returns:
            dict with all three metric results
        """
        cv = generated_concept_vectors.cpu().float().numpy()
        result = {}
        result["inter_sentence_cosine"] = self.inter_sentence_cosine_similarity(cv)
        result["concept_drift"] = self.concept_drift_score(cv)
        if compute_irac:
            try:
                result["argument_progression"] = self.argument_progression_score(cv)
            except Exception as e:
                logger.warning(f"IRAC scoring failed: {e}")
                result["argument_progression"] = None
        return result
