"""
concept_lm/evaluation/autobleu.py

AutoBLEU: measures round-trip fidelity of concept representations.

Protocol:
    1. Encode sentence s into concept vector c via the model's pooler
       (using known sentence boundaries, so we isolate the pooler's quality).
    2. Decode c back to text using the SONAR decoder.
    3. Compute BLEU between original s and reconstructed s'.

This directly measures how much semantic content survives the
encode → concept → decode round-trip. It is the primary diagnostic
for whether the concept space is lossless enough for legal reasoning.

High AutoBLEU: concept vectors faithfully represent their source sentences.
Low AutoBLEU: the concept bottleneck is too lossy — likely caused by mean
              pooling losing intra-segment token ordering.

Usage:
    from concept_lm.evaluation.autobleu import AutoBLEUEvaluator
    evaluator = AutoBLEUEvaluator(model, device="cuda")
    score = evaluator.evaluate(sentences, boundaries_per_sentence=1)
"""

from __future__ import annotations

import logging
from typing import Optional

import torch
import numpy as np
from sacrebleu.metrics import BLEU

logger = logging.getLogger(__name__)

bleu_metric = BLEU(effective_order=True)


class AutoBLEUEvaluator:
    """
    Evaluates concept encoding fidelity via SONAR decode round-trip.

    Requires SONAR decoder at evaluation time.
    This evaluator is only used during evaluation runs, not training.
    """

    def __init__(
        self,
        model,
        sonar_decoder=None,
        device: str = "cuda",
    ) -> None:
        """
        Args:
            model:          trained ConceptLM
            sonar_decoder:  EmbeddingToTextModelPipeline from sonar-space.
                            If None, loads automatically (requires sonar-space installed).
            device:         compute device
        """
        self.model = model
        self.device = device

        if sonar_decoder is None:
            sonar_decoder = self._load_sonar_decoder(device)
        self.decoder = sonar_decoder

    @staticmethod
    def _load_sonar_decoder(device: str):
        try:
            from sonar.inference_pipelines.text import EmbeddingToTextModelPipeline
            return EmbeddingToTextModelPipeline(
                decoder="text_sonar_basic_decoder",
                tokenizer="text_sonar_basic_encoder",
                device=torch.device(device),
            )
        except ImportError:
            raise RuntimeError(
                "SONAR required for AutoBLEU evaluation. "
                "Install: pip install sonar-space fairseq2"
            )

    @torch.no_grad()
    def evaluate_sentences(
        self,
        sentences: list[str],
        tokenizer,
        batch_size: int = 32,
    ) -> dict:
        """
        Encode sentences through the model's concept pooler and decode back.
        Compute BLEU between original and reconstructed.

        Args:
            sentences:  list of sentence strings
            tokenizer:  GPT-2 tokenizer
            batch_size: sentences per batch

        Returns:
            dict with mean BLEU, per-sentence scores, and failure examples
        """
        self.model.eval()
        all_bleu_scores = []
        reconstructed = []
        failed = []

        for i in range(0, len(sentences), batch_size):
            batch_sents = sentences[i:i + batch_size]
            batch_reconstructed = self._encode_decode_batch(batch_sents, tokenizer)

            for orig, recon in zip(batch_sents, batch_reconstructed):
                if recon is None:
                    failed.append(orig[:100])
                    all_bleu_scores.append(0.0)
                    reconstructed.append("")
                    continue
                score = bleu_metric.sentence_score(recon, [orig]).score
                all_bleu_scores.append(score)
                reconstructed.append(recon)

        return {
            "mean_bleu": float(np.mean(all_bleu_scores)) if all_bleu_scores else 0.0,
            "median_bleu": float(np.median(all_bleu_scores)) if all_bleu_scores else 0.0,
            "n_evaluated": len(all_bleu_scores),
            "n_failed": len(failed),
            "examples": [
                {"original": sentences[j], "reconstructed": reconstructed[j], "bleu": all_bleu_scores[j]}
                for j in range(min(5, len(sentences)))
            ],
        }

    def _encode_decode_batch(
        self,
        sentences: list[str],
        tokenizer,
    ) -> list[Optional[str]]:
        """
        Encode each sentence independently through the model pooler,
        then decode via SONAR.

        Returns list of reconstructed strings (None on error).
        """
        results = []
        for sent in sentences:
            try:
                ids = tokenizer.encode(sent, return_tensors="pt").to(self.device)
                if ids.shape[1] == 0:
                    results.append(None)
                    continue

                H = self.model.encoder(ids)              # (1, L, d_token)
                # Treat the whole sentence as one concept (no boundary splitting)
                b = torch.zeros(1, ids.shape[1], device=self.device)
                b[0, 0] = 1.0
                C, C_mask, _ = self.model.pooler(H, b)  # (1, 1, d_concept)
                c = C[0, 0]                              # (d_concept,)

                # Decode via SONAR
                c_t = c.unsqueeze(0).cpu()               # (1, d_concept)
                recon = self.decoder.predict(
                    c_t, target_lang="eng_Latn", max_seq_len=256
                )[0]
                results.append(recon)
            except Exception as e:
                logger.debug(f"Encode-decode failed for sentence: {e}")
                results.append(None)
        return results

    @torch.no_grad()
    def evaluate_from_dataset(
        self,
        data_dir: str,
        tokenizer,
        n_cases: int = 50,
        sentences_per_case: int = 20,
    ) -> dict:
        """
        Convenience method: sample sentences from the processed dataset
        and run AutoBLEU evaluation.
        """
        import json
        from pathlib import Path
        import random

        data_path = Path(data_dir)
        json_files = sorted(data_path.glob("*.json"))
        json_files = [f for f in json_files if "report" not in f.name]

        selected = random.sample(json_files, min(n_cases, len(json_files)))
        sentences = []
        for jf in selected:
            try:
                record = json.loads(jf.read_text())
                sents = record.get("sentences", [])
                sentences.extend(sents[:sentences_per_case])
            except Exception:
                continue

        logger.info(f"AutoBLEU: evaluating {len(sentences)} sentences from {len(selected)} cases")
        return self.evaluate_sentences(sentences, tokenizer)
