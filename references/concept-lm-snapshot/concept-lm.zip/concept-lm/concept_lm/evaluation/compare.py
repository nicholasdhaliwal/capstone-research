"""
concept_lm/evaluation/compare.py

Comparison runner: ConceptLM vs. GPT-2 baseline on all evaluation metrics.

Runs both models through the same evaluation suite and produces a
structured comparison report. This is the main deliverable for the
capstone evaluation section.

Metrics compared:
    - Validation NTP perplexity (lower = better)
    - AutoBLEU on held-out sentences (higher = better)
    - Inter-sentence coherence score
    - Concept drift score
    - Argument progression score (legal reasoning structure)
    - Outcome prediction cosine similarity

Usage:
    python -m concept_lm.evaluation.compare \
        --concept-lm-checkpoint checkpoints/best.pt \
        --gpt2-checkpoint checkpoints/gpt2_finetuned/ \
        --data-dir data/processed/ \
        --segmented-dir data/segmented/ \
        --output comparison_report.json
"""

from __future__ import annotations

import json
import logging
import argparse
import math
from pathlib import Path
from typing import Optional

import torch
import numpy as np
from tqdm import tqdm

logger = logging.getLogger(__name__)


def load_concept_lm(checkpoint_path: str, device: str = "cuda"):
    """Load ConceptLM from a training checkpoint."""
    from concept_lm.model.concept_lm import ConceptLM
    from concept_lm.config import ConceptLMConfig

    ckpt = torch.load(checkpoint_path, map_location=device)
    cfg = ConceptLMConfig.from_dict(ckpt["config"])
    model = ConceptLM(cfg).to(device)
    model.load_state_dict(ckpt["model_state"])
    model.eval()
    return model, cfg


def load_gpt2_baseline(checkpoint_dir: str, device: str = "cuda"):
    """Load fine-tuned GPT-2 from a HuggingFace checkpoint directory."""
    from transformers import GPT2LMHeadModel, GPT2Tokenizer
    model = GPT2LMHeadModel.from_pretrained(checkpoint_dir).to(device).eval()
    tokenizer = GPT2Tokenizer.from_pretrained(checkpoint_dir)
    tokenizer.pad_token = tokenizer.eos_token
    return model, tokenizer


@torch.no_grad()
def compute_perplexity_gpt2(model, tokenizer, data_dir: str, device: str, n_cases: int = 100) -> float:
    """Compute GPT-2 perplexity on held-out test cases."""
    import random
    from pathlib import Path
    import numpy as np

    test_dir = Path(data_dir) / "test"
    token_files = list(test_dir.glob("*_tokens.npy"))
    selected = random.sample(token_files, min(n_cases, len(token_files)))

    total_loss = 0.0
    total_tokens = 0

    for tf in selected:
        tokens = np.load(tf).astype(np.int64)
        ids = torch.tensor([tokens[:1024]], device=device)
        labels = ids.clone()
        out = model(ids, labels=labels)
        total_loss += out.loss.item() * ids.shape[1]
        total_tokens += ids.shape[1]

    return math.exp(total_loss / max(total_tokens, 1))


@torch.no_grad()
def compute_perplexity_concept_lm(model, data_dir: str, device: str, n_cases: int = 100) -> float:
    """Compute ConceptLM NTP perplexity on held-out test cases."""
    import random
    import numpy as np
    from pathlib import Path
    import torch.nn.functional as F

    test_dir = Path(data_dir) / "test"
    token_files = list(test_dir.glob("*_tokens.npy"))
    selected = random.sample(token_files, min(n_cases, len(token_files)))

    total_loss = 0.0
    total_tokens = 0
    cfg = model.cfg.model

    for tf in selected:
        tokens = np.load(tf).astype(np.int64)
        ids = torch.tensor([tokens[:cfg.max_seq_len]], device=device)
        logits, losses = model(ids, labels=ids)
        if losses is not None:
            total_loss += losses.ntp.item() * ids.shape[1]
            total_tokens += ids.shape[1]

    return math.exp(total_loss / max(total_tokens, 1))


def run_comparison(
    concept_lm_checkpoint: str,
    gpt2_checkpoint: str,
    data_dir: str,
    segmented_dir: str,
    output_path: str,
    device: str = "cuda",
    n_eval_cases: int = 100,
) -> dict:
    from transformers import GPT2Tokenizer
    from concept_lm.evaluation.autobleu import AutoBLEUEvaluator
    from concept_lm.evaluation.coherence import CoherenceEvaluator
    from concept_lm.evaluation.reasoning import ReasoningEvaluator

    tokenizer = GPT2Tokenizer.from_pretrained("gpt2")
    tokenizer.pad_token = tokenizer.eos_token

    report = {
        "concept_lm_checkpoint": concept_lm_checkpoint,
        "gpt2_checkpoint": gpt2_checkpoint,
        "n_eval_cases": n_eval_cases,
    }

    # ── ConceptLM evaluation ───────────────────────────────────────────────
    logger.info("Loading ConceptLM...")
    clm, clm_cfg = load_concept_lm(concept_lm_checkpoint, device)

    logger.info("ConceptLM: perplexity...")
    clm_ppl = compute_perplexity_concept_lm(clm, data_dir, device, n_eval_cases)

    logger.info("ConceptLM: AutoBLEU...")
    autobleu_eval = AutoBLEUEvaluator(clm, device=device)
    clm_autobleu = autobleu_eval.evaluate_from_dataset(
        segmented_dir, tokenizer, n_cases=n_eval_cases
    )

    logger.info("ConceptLM: reasoning evaluation...")
    reasoning_eval = ReasoningEvaluator(clm, device=device)
    clm_reasoning = reasoning_eval.evaluate_from_dataset(
        segmented_dir, tokenizer, n_cases=n_eval_cases
    )

    report["concept_lm"] = {
        "perplexity": clm_ppl,
        "autobleu": clm_autobleu,
        "reasoning": clm_reasoning,
    }
    del clm
    torch.cuda.empty_cache() if device == "cuda" else None

    # ── GPT-2 baseline evaluation ──────────────────────────────────────────
    logger.info("Loading GPT-2 baseline...")
    gpt2, gpt2_tok = load_gpt2_baseline(gpt2_checkpoint, device)

    logger.info("GPT-2: perplexity...")
    gpt2_ppl = compute_perplexity_gpt2(gpt2, gpt2_tok, data_dir, device, n_eval_cases)

    report["gpt2_baseline"] = {
        "perplexity": gpt2_ppl,
    }

    # ── Summary ────────────────────────────────────────────────────────────
    report["summary"] = {
        "perplexity_delta": clm_ppl - gpt2_ppl,
        "concept_lm_wins_perplexity": clm_ppl < gpt2_ppl,
        "clm_mean_outcome_cosine": clm_reasoning.get("mean_outcome_cosine", 0),
        "clm_mean_autobleu": clm_autobleu.get("mean_bleu", 0),
    }

    Path(output_path).write_text(json.dumps(report, indent=2))
    logger.info(f"Comparison report written to {output_path}")
    return report


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
    parser = argparse.ArgumentParser(description="Compare ConceptLM vs GPT-2 baseline")
    parser.add_argument("--concept-lm-checkpoint", required=True)
    parser.add_argument("--gpt2-checkpoint", required=True)
    parser.add_argument("--data-dir", default="data/processed/")
    parser.add_argument("--segmented-dir", default="data/segmented/")
    parser.add_argument("--output", default="comparison_report.json")
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--n-eval-cases", type=int, default=100)
    args = parser.parse_args()

    report = run_comparison(
        args.concept_lm_checkpoint,
        args.gpt2_checkpoint,
        args.data_dir,
        args.segmented_dir,
        args.output,
        args.device,
        args.n_eval_cases,
    )
    print(json.dumps(report["summary"], indent=2))


if __name__ == "__main__":
    main()
