"""
baseline/finetune_gpt2.py

Fine-tune GPT-2 on the legal opinion corpus for next-token prediction.
This is the token-level baseline for comparison against ConceptLM.

Training setup:
    - Base model: GPT-2 (117M params) from HuggingFace
    - Objective: standard causal language modeling (NTP)
    - Data: same tokenized corpus used for ConceptLM training
    - Evaluation: NTP perplexity on held-out test cases
    - The baseline shares the same tokenizer as ConceptLM (GPT-2 BPE)
      so perplexity comparisons are apples-to-apples.

Usage:
    python baseline/finetune_gpt2.py \
        --data-dir data/processed/ \
        --output-dir checkpoints/gpt2_finetuned/ \
        --epochs 3 \
        --batch-size 8 \
        --lr 2e-5
"""

from __future__ import annotations

import os
import math
import json
import logging
import argparse
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import Dataset, DataLoader
from transformers import (
    GPT2LMHeadModel,
    GPT2Tokenizer,
    get_cosine_schedule_with_warmup,
)
from tqdm import tqdm

logger = logging.getLogger(__name__)


class LegalTokenDataset(Dataset):
    """Loads pre-tokenized arrays from data/processed/{split}/."""

    def __init__(self, data_dir: str, max_length: int = 1024) -> None:
        self.path = Path(data_dir)
        self.files = sorted(self.path.glob("*_tokens.npy"))
        self.max_length = max_length

    def __len__(self) -> int:
        return len(self.files)

    def __getitem__(self, idx: int) -> torch.Tensor:
        tokens = np.load(self.files[idx]).astype(np.int64)
        tokens = tokens[:self.max_length]
        return torch.tensor(tokens, dtype=torch.long)


def collate_fn(batch: list[torch.Tensor]) -> dict[str, torch.Tensor]:
    max_len = max(t.shape[0] for t in batch)
    input_ids = torch.full((len(batch), max_len), fill_value=50256, dtype=torch.long)  # pad with EOS
    attention_mask = torch.zeros(len(batch), max_len, dtype=torch.long)
    for i, t in enumerate(batch):
        input_ids[i, :t.shape[0]] = t
        attention_mask[i, :t.shape[0]] = 1
    return {"input_ids": input_ids, "attention_mask": attention_mask, "labels": input_ids.clone()}


def train(
    data_dir: str,
    output_dir: str,
    epochs: int = 3,
    batch_size: int = 8,
    lr: float = 2e-5,
    max_length: int = 1024,
    warmup_steps: int = 200,
    grad_accum: int = 4,
    device: Optional[str] = None,
) -> dict:
    from typing import Optional
    if device is None:
        device = "cuda" if torch.cuda.is_available() else "cpu"

    out_path = Path(output_dir)
    out_path.mkdir(parents=True, exist_ok=True)

    tokenizer = GPT2Tokenizer.from_pretrained("gpt2")
    tokenizer.pad_token = tokenizer.eos_token

    model = GPT2LMHeadModel.from_pretrained("gpt2").to(device)
    logger.info(f"GPT-2 parameters: {sum(p.numel() for p in model.parameters()):,}")

    train_ds = LegalTokenDataset(f"{data_dir}/train", max_length)
    val_ds = LegalTokenDataset(f"{data_dir}/val", max_length)
    train_loader = DataLoader(train_ds, batch_size=batch_size, shuffle=True,
                              collate_fn=collate_fn, num_workers=2, drop_last=True)
    val_loader = DataLoader(val_ds, batch_size=batch_size, shuffle=False,
                            collate_fn=collate_fn, num_workers=2)

    optimizer = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=0.01)
    total_steps = len(train_loader) * epochs // grad_accum
    scheduler = get_cosine_schedule_with_warmup(optimizer, warmup_steps, total_steps)

    best_val_ppl = float("inf")
    global_step = 0
    training_log = []

    for epoch in range(epochs):
        model.train()
        optimizer.zero_grad()
        running_loss = 0.0
        accum = 0

        for batch in tqdm(train_loader, desc=f"Epoch {epoch+1}/{epochs}"):
            batch = {k: v.to(device) if isinstance(v, torch.Tensor) else v for k, v in batch.items()}
            with torch.autocast(device_type=device, dtype=torch.bfloat16, enabled=(device=="cuda")):
                out = model(**batch)
            loss = out.loss / grad_accum
            loss.backward()
            running_loss += out.loss.item()
            accum += 1

            if accum == grad_accum:
                torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
                optimizer.step()
                scheduler.step()
                optimizer.zero_grad()
                accum = 0
                global_step += 1

                if global_step % 100 == 0:
                    avg_loss = running_loss / 100
                    logger.info(f"  step {global_step} | loss {avg_loss:.4f}")
                    running_loss = 0.0

        # Validation
        model.eval()
        val_loss = 0.0
        n_batches = 0
        with torch.no_grad():
            for batch in val_loader:
                batch = {k: v.to(device) if isinstance(v, torch.Tensor) else v for k, v in batch.items()}
                out = model(**batch)
                val_loss += out.loss.item()
                n_batches += 1

        avg_val_loss = val_loss / max(n_batches, 1)
        val_ppl = math.exp(avg_val_loss)
        logger.info(f"Epoch {epoch+1} | val_loss={avg_val_loss:.4f} | val_ppl={val_ppl:.2f}")
        training_log.append({"epoch": epoch+1, "val_loss": avg_val_loss, "val_ppl": val_ppl})

        if val_ppl < best_val_ppl:
            best_val_ppl = val_ppl
            model.save_pretrained(out_path / "best")
            tokenizer.save_pretrained(out_path / "best")
            logger.info(f"  New best: ppl={val_ppl:.2f} — saved to {out_path}/best")

    model.save_pretrained(out_path / "final")
    tokenizer.save_pretrained(out_path / "final")

    result = {
        "best_val_ppl": best_val_ppl,
        "training_log": training_log,
        "output_dir": str(output_dir),
    }
    (out_path / "train_log.json").write_text(json.dumps(result, indent=2))
    return result


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
    parser = argparse.ArgumentParser(description="Fine-tune GPT-2 on legal corpus")
    parser.add_argument("--data-dir", default="data/processed/")
    parser.add_argument("--output-dir", default="checkpoints/gpt2_finetuned/")
    parser.add_argument("--epochs", type=int, default=3)
    parser.add_argument("--batch-size", type=int, default=8)
    parser.add_argument("--lr", type=float, default=2e-5)
    parser.add_argument("--max-length", type=int, default=1024)
    parser.add_argument("--grad-accum", type=int, default=4)
    args = parser.parse_args()

    result = train(
        args.data_dir, args.output_dir, args.epochs,
        args.batch_size, args.lr, args.max_length, grad_accum=args.grad_accum,
    )
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
