"""
baseline/eval_gpt2.py

Evaluation script for the fine-tuned GPT-2 baseline.

Runs the same evaluation metrics as ConceptLM where applicable:
    - Perplexity on held-out test cases
    - Generation quality on sample prompts (qualitative)
    - Token-level coherence (inter-sentence similarity of generated text
      after re-encoding through SONAR for apples-to-apples comparison)

Usage:
    python baseline/eval_gpt2.py \
        --checkpoint checkpoints/gpt2_finetuned/best \
        --data-dir data/processed/ \
        --segmented-dir data/segmented/ \
        --output gpt2_eval_report.json
"""

from __future__ import annotations

import json
import math
import logging
import argparse
import random
from pathlib import Path
from typing import Optional

import numpy as np
import torch
from tqdm import tqdm

logger = logging.getLogger(__name__)


def load_model(checkpoint_dir: str, device: str):
    from transformers import GPT2LMHeadModel, GPT2Tokenizer
    model = GPT2LMHeadModel.from_pretrained(checkpoint_dir).to(device).eval()
    tokenizer = GPT2Tokenizer.from_pretrained(checkpoint_dir)
    tokenizer.pad_token = tokenizer.eos_token
    return model, tokenizer


@torch.no_grad()
def compute_test_perplexity(
    model,
    tokenizer,
    data_dir: str,
    device: str,
    n_cases: int = 200,
    max_length: int = 1024,
) -> dict:
    test_dir = Path(data_dir) / "test"
    token_files = list(test_dir.glob("*_tokens.npy"))
    selected = random.sample(token_files, min(n_cases, len(token_files)))

    total_loss = 0.0
    total_tokens = 0

    for tf in tqdm(selected, desc="Computing perplexity"):
        tokens = np.load(tf).astype(np.int64)[:max_length]
        ids = torch.tensor([tokens], device=device)
        labels = ids.clone()
        out = model(input_ids=ids, labels=labels)
        total_loss += out.loss.item() * ids.shape[1]
        total_tokens += ids.shape[1]

    avg_loss = total_loss / max(total_tokens, 1)
    return {
        "test_ntp_loss": avg_loss,
        "test_perplexity": math.exp(avg_loss),
        "n_cases": len(selected),
        "total_tokens": total_tokens,
    }


@torch.no_grad()
def generate_samples(
    model,
    tokenizer,
    prompts: list[str],
    device: str,
    max_new_tokens: int = 150,
    temperature: float = 0.8,
    top_p: float = 0.9,
) -> list[dict]:
    results = []
    for prompt in prompts:
        ids = tokenizer.encode(prompt, return_tensors="pt").to(device)
        out = model.generate(
            ids,
            max_new_tokens=max_new_tokens,
            temperature=temperature,
            top_p=top_p,
            do_sample=True,
            pad_token_id=tokenizer.eos_token_id,
        )
        generated = tokenizer.decode(out[0][ids.shape[1]:], skip_special_tokens=True)
        results.append({"prompt": prompt, "generated": generated})
    return results


LEGAL_PROMPTS = [
    "The plaintiff alleges that she was terminated because of her race. The employer claims",
    "Under McDonnell Douglas, the plaintiff must first establish a prima facie case. The court finds",
    "The defendant has articulated a legitimate, non-discriminatory reason for the termination. The plaintiff now bears the burden of",
    "After reviewing the record in its entirety, the court concludes that",
]


def evaluate(
    checkpoint_dir: str,
    data_dir: str,
    segmented_dir: str,
    output_path: str,
    device: str = "cuda",
    n_cases: int = 200,
) -> dict:
    model, tokenizer = load_model(checkpoint_dir, device)

    logger.info("Computing test perplexity...")
    ppl_results = compute_test_perplexity(model, tokenizer, data_dir, device, n_cases)

    logger.info("Generating sample completions...")
    generation_results = generate_samples(model, tokenizer, LEGAL_PROMPTS, device)

    report = {
        "checkpoint": checkpoint_dir,
        "perplexity": ppl_results,
        "generations": generation_results,
    }

    Path(output_path).write_text(json.dumps(report, indent=2))
    logger.info(f"GPT-2 eval report written to {output_path}")
    return report


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
    parser = argparse.ArgumentParser(description="Evaluate fine-tuned GPT-2 baseline")
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--data-dir", default="data/processed/")
    parser.add_argument("--segmented-dir", default="data/segmented/")
    parser.add_argument("--output", default="gpt2_eval_report.json")
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--n-cases", type=int, default=200)
    args = parser.parse_args()

    report = evaluate(
        args.checkpoint, args.data_dir, args.segmented_dir,
        args.output, args.device, args.n_cases,
    )
    print(json.dumps(report["perplexity"], indent=2))


if __name__ == "__main__":
    main()
