"""
scripts/generate.py

Interactive generation from a trained ConceptLM checkpoint.

Usage:
    # Interactive REPL:
    python scripts/generate.py --checkpoint checkpoints/best.pt

    # Single prompt:
    python scripts/generate.py \
        --checkpoint checkpoints/best.pt \
        --prompt "The plaintiff alleges disparate treatment under Title VII." \
        --max-tokens 200
"""

from __future__ import annotations

import argparse
import logging
import torch

logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate text with trained ConceptLM")
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--prompt", default=None, help="Single prompt (omit for interactive mode)")
    parser.add_argument("--max-tokens", type=int, default=256)
    parser.add_argument("--temperature", type=float, default=0.8)
    parser.add_argument("--top-p", type=float, default=0.9)
    parser.add_argument("--device", default=None)
    args = parser.parse_args()

    device = args.device or ("cuda" if torch.cuda.is_available() else "cpu")

    from concept_lm.model.concept_lm import ConceptLM
    from concept_lm.config import ConceptLMConfig
    from concept_lm.inference.generate import stream_generate
    from transformers import GPT2Tokenizer

    ckpt = torch.load(args.checkpoint, map_location=device)
    cfg = ConceptLMConfig.from_dict(ckpt["config"])
    model = ConceptLM(cfg).to(device)
    model.load_state_dict(ckpt["model_state"])
    model.eval()

    tokenizer = GPT2Tokenizer.from_pretrained("gpt2")
    tokenizer.pad_token = tokenizer.eos_token

    print(f"\nConceptLM loaded ({model.n_params:,} params) | device={device}")
    print(f"Temperature={args.temperature}  top_p={args.top_p}  max_tokens={args.max_tokens}\n")

    def run_prompt(prompt: str) -> None:
        print(f"\nPROMPT: {prompt}\n\nGENERATED: ", end="", flush=True)
        for token in stream_generate(
            model, prompt, tokenizer,
            max_new_tokens=args.max_tokens,
            temperature=args.temperature,
            top_p=args.top_p,
            device=device,
        ):
            print(token, end="", flush=True)
        print("\n")

    if args.prompt:
        run_prompt(args.prompt)
    else:
        print("Interactive mode. Type a prompt and press Enter. Ctrl+C to exit.\n")
        while True:
            try:
                prompt = input("PROMPT> ").strip()
                if prompt:
                    run_prompt(prompt)
            except KeyboardInterrupt:
                print("\nExiting.")
                break
            except EOFError:
                break


if __name__ == "__main__":
    main()
