#!/usr/bin/env bash
# scripts/run_pipeline.sh
#
# End-to-end pipeline: scrape → deduplicate → segment → encode → tokenize → build → train
#
# Usage:
#   bash scripts/run_pipeline.sh                        # full pipeline, default config
#   bash scripts/run_pipeline.sh --dry-run              # verify pipeline with synthetic data
#   bash scripts/run_pipeline.sh --skip-scrape          # resume from existing raw data
#   bash scripts/run_pipeline.sh --skip-preprocess      # resume from existing processed data
#
# Environment variables:
#   COURTLISTENER_API_TOKEN   CourtListener API token (required for scraping)
#   DEVICE                    Training device: cuda or cpu (default: cuda if available)
#   CONFIG_MODEL              Path to model config (default: configs/model_small.yaml)
#   CONFIG_TRAIN              Path to train config (default: configs/train_default.yaml)

set -euo pipefail

# ── Parse arguments ──────────────────────────────────────────────────────────
DRY_RUN=0
SKIP_SCRAPE=0
SKIP_PREPROCESS=0

for arg in "$@"; do
    case $arg in
        --dry-run)          DRY_RUN=1 ;;
        --skip-scrape)      SKIP_SCRAPE=1 ;;
        --skip-preprocess)  SKIP_PREPROCESS=1 ;;
        *)                  echo "Unknown argument: $arg"; exit 1 ;;
    esac
done

# ── Config ───────────────────────────────────────────────────────────────────
DEVICE="${DEVICE:-$(python -c 'import torch; print("cuda" if torch.cuda.is_available() else "cpu")')}"
CONFIG_MODEL="${CONFIG_MODEL:-configs/model_small.yaml}"
CONFIG_TRAIN="${CONFIG_TRAIN:-configs/train_default.yaml}"

RAW_DIR="data/raw"
CLEAN_DIR="data/raw_clean"
SEGMENTED_DIR="data/segmented"
ENCODED_DIR="data/encoded"
TOKENIZED_DIR="data/tokenized"
PROCESSED_DIR="data/processed"

echo "============================================================"
echo "  concept-lm pipeline"
echo "  device=${DEVICE}  dry_run=${DRY_RUN}"
echo "  model config: ${CONFIG_MODEL}"
echo "  train config: ${CONFIG_TRAIN}"
echo "============================================================"

if [ "$DRY_RUN" -eq 1 ]; then
    echo ""
    echo "[DRY RUN] Verifying full pipeline on synthetic data..."
    python scripts/train.py --dry-run --device "${DEVICE}"
    echo "[DRY RUN] Pipeline verified. No data or training required."
    exit 0
fi

# ── Step 1: Scrape ───────────────────────────────────────────────────────────
if [ "$SKIP_SCRAPE" -eq 0 ] && [ "$SKIP_PREPROCESS" -eq 0 ]; then
    echo ""
    echo "[1/6] Scraping CourtListener..."
    python -m data.scrape.courtlistener \
        --output-dir "${RAW_DIR}" \
        2>&1 | tee logs/scrape_courtlistener.log

    echo ""
    echo "[1b] Optional: scrape PACER/RECAP supplement..."
    echo "     Run manually: python -m data.scrape.pacer --output-dir data/raw/pacer/"

    echo ""
    echo "[2/6] Deduplicating..."
    python -m data.scrape.deduplicate \
        --input-dir "${RAW_DIR}" \
        --output-dir "${CLEAN_DIR}" \
        2>&1 | tee logs/dedup.log
fi

# ── Step 2: Preprocess ───────────────────────────────────────────────────────
if [ "$SKIP_PREPROCESS" -eq 0 ]; then
    mkdir -p logs

    echo ""
    echo "[3/6] Sentence segmentation..."
    python -m data.preprocess.segment \
        --input-dir "${CLEAN_DIR}" \
        --output-dir "${SEGMENTED_DIR}" \
        --segmenter spacy \
        --workers 4 \
        2>&1 | tee logs/segment.log

    echo ""
    echo "[4/6] SONAR encoding (may take 20-30 min on GPU)..."
    python -m data.preprocess.encode \
        --input-dir "${SEGMENTED_DIR}" \
        --output-dir "${ENCODED_DIR}" \
        --device "${DEVICE}" \
        --batch-size 32 \
        2>&1 | tee logs/encode.log

    echo ""
    echo "[5/6] GPT-2 tokenization..."
    python -m data.preprocess.tokenize_corpus \
        --input-dir "${SEGMENTED_DIR}" \
        --output-dir "${TOKENIZED_DIR}" \
        --workers 4 \
        2>&1 | tee logs/tokenize.log

    echo ""
    echo "[6a/6] Building dataset splits..."
    python -m data.preprocess.build_dataset \
        --tokenized-dir "${TOKENIZED_DIR}" \
        --encoded-dir "${ENCODED_DIR}" \
        --output-dir "${PROCESSED_DIR}" \
        2>&1 | tee logs/build_dataset.log

    echo ""
    echo "[6b/6] Dataset inspection..."
    python -m data.inspect \
        --data-dir "${PROCESSED_DIR}" \
        2>&1 | tee logs/inspect.log
fi

# ── Step 3: Train ────────────────────────────────────────────────────────────
echo ""
echo "[7/7] Training ConceptLM..."
mkdir -p logs checkpoints
python scripts/train.py \
    --model-config "${CONFIG_MODEL}" \
    --train-config "${CONFIG_TRAIN}" \
    --device "${DEVICE}" \
    2>&1 | tee logs/train.log

echo ""
echo "============================================================"
echo "  Pipeline complete."
echo "  Checkpoints: checkpoints/"
echo "  Logs:        logs/"
echo "============================================================"
