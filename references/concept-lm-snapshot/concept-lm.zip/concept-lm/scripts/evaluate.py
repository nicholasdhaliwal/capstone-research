"""
scripts/evaluate.py

Entry point for ConceptLM evaluation.

Usage:
    python scripts/evaluate.py \
        --checkpoint checkpoints/best.pt \
        --gpt2-checkpoint checkpoints/gpt2_finetuned/best \
        --data-dir data/processed/ \
        --segmented-dir data/segmented/ \
        --output reports/eval_report.json
"""

from __future__ import annotations

import argparse
import logging
import json

logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")


def main() -> None:
    parser = argparse.ArgumentParser(description="Evaluate ConceptLM and compare to GPT-2 baseline")
    parser.add_argument("--checkpoint", required=True, help="Path to ConceptLM checkpoint")
    parser.add_argument("--gpt2-checkpoint", required=True, help="Path to GPT-2 fine-tuned checkpoint dir")
    parser.add_argument("--data-dir", default="data/processed/")
    parser.add_argument("--segmented-dir", default="data/segmented/")
    parser.add_argument("--output", default="reports/eval_report.json")
    parser.add_argument("--device", default=None)
    parser.add_argument("--n-eval-cases", type=int, default=100)
    args = parser.parse_args()

    import torch
    device = args.device or ("cuda" if torch.cuda.is_available() else "cpu")

    from concept_lm.evaluation.compare import run_comparison
    report = run_comparison(
        concept_lm_checkpoint=args.checkpoint,
        gpt2_checkpoint=args.gpt2_checkpoint,
        data_dir=args.data_dir,
        segmented_dir=args.segmented_dir,
        output_path=args.output,
        device=device,
        n_eval_cases=args.n_eval_cases,
    )
    print(json.dumps(report["summary"], indent=2))


if __name__ == "__main__":
    main()
