"""
scripts/train.py

Entry point for ConceptLM training.

Usage:
    # Dry run (no data needed):
    python scripts/train.py --dry-run

    # Full training with default config:
    python scripts/train.py \
        --model-config configs/model_small.yaml \
        --train-config configs/train_default.yaml

    # Resume from checkpoint:
    python scripts/train.py \
        --model-config configs/model_small.yaml \
        --train-config configs/train_default.yaml \
        --resume checkpoints/checkpoint_step_4000.pt

    # Override individual config values:
    python scripts/train.py \
        --model-config configs/model_small.yaml \
        --train-config configs/train_default.yaml \
        --override training.lr_concept=1e-4 training.total_steps=50000
"""

from __future__ import annotations

import argparse
import logging
import sys

logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
logger = logging.getLogger(__name__)


def parse_override(overrides: list[str]) -> dict:
    """Parse 'key=value' strings into a nested dict."""
    result = {}
    for item in overrides:
        key, _, value = item.partition("=")
        parts = key.strip().split(".")
        d = result
        for part in parts[:-1]:
            d = d.setdefault(part, {})
        # Attempt type coercion
        v = value.strip()
        try:
            v = int(v)
        except ValueError:
            try:
                v = float(v)
            except ValueError:
                if v.lower() == "true":
                    v = True
                elif v.lower() == "false":
                    v = False
        d[parts[-1]] = v
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description="Train ConceptLM")
    parser.add_argument("--model-config", default="configs/model_small.yaml")
    parser.add_argument("--train-config", default="configs/train_default.yaml")
    parser.add_argument("--resume", default=None, help="Path to checkpoint to resume from")
    parser.add_argument("--dry-run", action="store_true", help="Run on synthetic data")
    parser.add_argument("--device", default=None)
    parser.add_argument("--override", nargs="*", default=[], metavar="key=value",
                        help="Override config values, e.g. training.lr_token=1e-4")
    args = parser.parse_args()

    if args.dry_run:
        # Import and run dry run directly
        from concept_lm.model.concept_lm import ConceptLM
        ConceptLM.dry_run(device=args.device or "cpu")
        sys.exit(0)

    from concept_lm.config import ConceptLMConfig, _deep_merge
    from concept_lm.training.trainer import Trainer

    cfg = ConceptLMConfig.from_yaml(args.model_config, args.train_config)

    if args.override:
        overrides = parse_override(args.override)
        cfg_dict = cfg.to_dict()
        _deep_merge(cfg_dict, overrides)
        cfg = ConceptLMConfig.from_dict(cfg_dict)

    trainer = Trainer(cfg, dry_run=False, device=args.device)

    if args.resume:
        trainer.load_checkpoint(args.resume)

    trainer.train()


if __name__ == "__main__":
    main()
