from setuptools import setup, find_packages

setup(
    name="concept-lm",
    version="0.1.0",
    description=(
        "Concept-Level Language Model for Structured Reasoning. "
        "Operates on dynamic learned concept tokens rather than subword tokens."
    ),
    packages=find_packages(),
    python_requires=">=3.10",
    install_requires=[
        "torch>=2.2.0",
        "numpy>=1.26.0",
        "transformers>=4.40.0",
        "pyyaml>=6.0.1",
        "omegaconf>=2.3.0",
        "click>=8.1.7",
        "tqdm>=4.66.0",
        "requests>=2.31.0",
    ],
    entry_points={
        "console_scripts": [
            "clm-train=scripts.train:main",
            "clm-eval=scripts.evaluate:main",
            "clm-generate=scripts.generate:main",
            "clm-scrape=data.scrape.courtlistener:main",
            "clm-preprocess=data.preprocess.build_dataset:main",
        ]
    },
)
