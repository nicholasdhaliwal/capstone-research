# concept-lm

**Concept-Level Language Model for Structured Reasoning**

A transformer-based encoder-decoder architecture that reasons in dynamic semantic concept space rather than token space. Designed for structured, long-form domains where global coherence matters — legal opinions, regulatory analysis, clinical notes.

---

## What this is

Standard LLMs predict the next subword token. This model predicts the next **concept** — a learned, variable-length semantic unit whose boundaries are discovered from the data rather than imposed by rules.

**At training time:**
- SONAR (Meta's multilingual sentence encoder) provides target embeddings for concept alignment and next-concept prediction supervision.
- Phase 1 warm-starts the boundary detector using known sentence boundaries.
- Phase 2 frees the boundary detector to discover its own boundaries from semantic shift.

**At inference time:**
- SONAR is not needed. The model is fully self-contained.
- Input: any text document (legal opinion, contract, research paper).
- Output: structured, coherent text generated from concept-level plans.

---

## Quickstart

```bash
# 1. Install
pip install -e .
pip install -r requirements.txt
python -m spacy download en_core_web_sm

# 2. Verify the full pipeline (no data needed)
python scripts/train.py --dry-run

# 3. Collect data
export COURTLISTENER_API_TOKEN=your_token_here
python -m data.scrape.courtlistener --output-dir data/raw/

# 4. Preprocess
python -m data.scrape.deduplicate --input-dir data/raw/ --output-dir data/raw_clean/
python -m data.preprocess.segment --input-dir data/raw_clean/ --output-dir data/segmented/
python -m data.preprocess.encode --input-dir data/segmented/ --output-dir data/encoded/
python -m data.preprocess.tokenize_corpus --input-dir data/segmented/ --output-dir data/tokenized/
python -m data.preprocess.build_dataset --output-dir data/processed/
python -m data.inspect --data-dir data/processed/

# 5. Train
python scripts/train.py \
    --model-config configs/model_small.yaml \
    --train-config configs/train_default.yaml

# 6. Train GPT-2 baseline
python baseline/finetune_gpt2.py --data-dir data/processed/ --output-dir checkpoints/gpt2_finetuned/

# 7. Evaluate
python scripts/evaluate.py \
    --checkpoint checkpoints/best.pt \
    --gpt2-checkpoint checkpoints/gpt2_finetuned/best \
    --output reports/eval_report.json

# 8. Generate interactively
python scripts/generate.py --checkpoint checkpoints/best.pt
```

Or run the full pipeline in one command:
```bash
bash scripts/run_pipeline.sh
```

---

## Architecture

```
Input Text
    │
    ▼  (data/preprocess/)
Sentence Segmentation (SpaCy / SaT)
    │
    ▼  (data/preprocess/encode.py — OFFLINE ONLY)
SONAR Encoding → target embeddings (.npy)
    │
    ├──────────────────────────────────────────┐
    ▼                                          ▼
Tokenization (GPT-2 BPE)              SONAR targets stored on disk
    │
    ▼  (concept_lm/model/encoder.py)
TokenEncoder  →  H  (B, L, d_token)
    │
    ▼  (concept_lm/model/boundary.py)
BoundaryDetector  →  b  (B, L)  binary boundaries
                  →  p  (B, L)  boundary probabilities
    │
    ▼  (concept_lm/model/pooler.py)
ConceptPooler  →  C  (B, M, d_concept)   M << L
    │
    ▼  (concept_lm/model/concept_transformer.py)
ConceptTransformer  →  Z  (B, M, d_concept)  enriched
                    →  P  (B, M, d_concept)  next-concept predictions
    │
    ▼  (concept_lm/model/decoder.py)
CrossAttentionDecoder (dual-source: Z + H)
    │
    ▼
Logits  (B, L, vocab_size)
```

**Full documents** (longer than `max_seq_len`) are handled by chunking with overlap, stitching concept sequences with a learned `[DOC_SEP]` vector, and processing the full stitched concept sequence through a single ConceptTransformer pass.

---

## Training phases

| Phase | Steps | Boundary supervision | Balance weight |
|---|---|---|---|
| 1 | 0 → 20% of total | BCE against SpaCy sentence boundaries | low (0.01) |
| 2 | 20% → end | None — free learned boundaries | high (0.05) |

Phase 1 checkpoint ≈ capstone deliverable (replicates Meta LCM with learned pooler).
Phase 2 checkpoint = full product (dynamic concept boundaries, novel contribution).

---

## Loss function

```
L = L_NTP           next-token prediction cross-entropy         (always)
  + w_align    * L_align       concept vector → SONAR sentence  (always)
  + w_next     * L_next_concept  transformer output → SONAR next (always)
  + w_bce      * L_boundary_bce  detector → sentence breaks      (Phase 1 only)
  + w_balance  * L_load_balance  boundary rate → target 1/R      (always)
```

---

## Repository structure

```
concept-lm/
├── concept_lm/
│   ├── config.py               Central config dataclass
│   ├── model/
│   │   ├── encoder.py          TokenEncoder (causal Transformer)
│   │   ├── boundary.py         BoundaryDetector + GlobalLoadBalancer
│   │   ├── pooler.py           ConceptPooler (Transformer segment encoder)
│   │   ├── concept_transformer.py  ConceptTransformer (reasoning backbone)
│   │   ├── decoder.py          CrossAttentionDecoder (dual-source)
│   │   └── concept_lm.py       Full model + LossBundle
│   ├── training/
│   │   ├── dataset.py          ConceptLMDataset + DryRunDataset
│   │   ├── losses.py           LossWeightSchedule (phase-aware)
│   │   ├── optimizer.py        Decoupled muP AdamW
│   │   ├── scheduler.py        Warmup + cosine decay
│   │   └── trainer.py          Full training loop
│   ├── inference/
│   │   ├── cache.py            KV cache
│   │   └── generate.py         Streaming generation
│   └── evaluation/
│       ├── autobleu.py         Round-trip fidelity
│       ├── coherence.py        Inter-sentence cosine + IRAC progression
│       ├── reasoning.py        Legal outcome prediction
│       └── compare.py          ConceptLM vs. GPT-2 comparison runner
├── data/
│   ├── scrape/
│   │   ├── courtlistener.py    Configurable CourtListener API client
│   │   ├── pacer.py            PACER/RECAP supplemental scraper
│   │   └── deduplicate.py      Exact + near-dedup + quality filter
│   └── preprocess/
│       ├── segment.py          SpaCy / SaT sentence segmentation
│       ├── encode.py           SONAR offline encoding
│       ├── tokenize_corpus.py  GPT-2 tokenization + boundary alignment
│       └── build_dataset.py    Train/val/test split assembly
├── baseline/
│   ├── finetune_gpt2.py        GPT-2 NTP fine-tuning
│   └── eval_gpt2.py            GPT-2 evaluation
├── scripts/
│   ├── train.py                Training entry point
│   ├── evaluate.py             Evaluation entry point
│   ├── generate.py             Interactive generation
│   └── run_pipeline.sh         Full end-to-end pipeline
├── configs/
│   ├── model_small.yaml        ~125M params, 8GB VRAM
│   ├── model_medium.yaml       ~350M params, A100
│   └── train_default.yaml      Training hyperparameters
└── notebooks/
    ├── 01_data_exploration.ipynb
    ├── 02_sonar_sanity_check.ipynb
    ├── 03_boundary_detection_dev.ipynb
    ├── 04_training_diagnostics.ipynb
    └── 05_evaluation_results.ipynb
```

---

## Key papers

| Paper | What it provides |
|---|---|
| [LCM (Meta 2024)](https://arxiv.org/abs/2412.08821) | Concept-level reasoning via SONAR; fixed sentence boundaries |
| [DLCM (ByteDance 2025)](https://arxiv.org/abs/2512.24617) | Learned boundaries; compression-aware scaling law; decoupled muP |
| [H-Net (CMU 2025)](https://arxiv.org/abs/2507.07955) | Dynamic chunking; EMA smoothing; SSM encoder bias |
| [BLT (Meta 2024)](https://arxiv.org/abs/2412.09871) | Entropy patching; tripartite encoder/backbone/decoder |
| [SONAR (Meta 2023)](https://arxiv.org/abs/2308.11466) | 1024-dim multilingual sentence embeddings; training target |
| [COCONUT (Meta 2024)](https://arxiv.org/abs/2412.06769) | Latent reasoning; multi-stage curriculum training |
| [CoCoMix (Meta 2025)](https://arxiv.org/abs/2502.08524) | SAE concept supervision + joint NTP objective |
| [Mamba (CMU 2023)](https://arxiv.org/abs/2312.00752) | SSM encoder with compression inductive bias |
| [Scaling Laws (OpenAI 2020)](https://arxiv.org/abs/2001.08361) | Baseline scaling framework |
| [muP (Microsoft 2022)](https://arxiv.org/abs/2203.03466) | Zero-shot LR transfer for heterogeneous architectures |

---

## Known limitations

- **No concept-level KV cache yet**: `generate.py` reprocesses the full context at each step. Full KV cache is stubbed in `inference/cache.py` but not yet integrated into the generation loop.
- **SONAR required for evaluation metrics**: AutoBLEU and argument progression scoring require `sonar-space`. Training and inference do not.
- **Mean pooling fallback**: Set `pooler_type = "mean"` in `ConceptPooler` for faster experimentation; the Transformer segment encoder is more expressive but slower.
- **Single-GPU only**: Distributed training via `accelerate` is not yet wired up. Use gradient accumulation to simulate larger batch sizes on a single GPU.

---

## Citation

If you use this work, please cite:
```
@misc{conceptlm2026,
  title  = {Concept-Level Language Modeling for Structured Reasoning},
  author = {Dhaliwal, Nicholas and Jensen, Jaysen and Mikhail, Nicholas},
  year   = {2026},
  school = {University of Chicago, MS in Applied Data Science}
}
```
